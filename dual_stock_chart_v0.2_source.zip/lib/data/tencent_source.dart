import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'market_data_source.dart';
import 'models.dart';

/// Free public Tencent Finance endpoints (A-shares, indices, US stocks).
/// Daily bars only. Not an official/licensed feed: no real-time guarantee.
class TencentDataSource implements MarketDataSource {
  static const int _barCount = 800;
  static const Map<String, String> _headers = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13) DualStockChart/0.2',
    'Referer': 'https://gu.qq.com/',
  };

  @override
  String get name => '腾讯财经';

  Future<http.Response> _get(Uri uri, Duration timeout) async {
    try {
      final r = await http.get(uri, headers: _headers).timeout(timeout);
      if (r.statusCode != 200) {
        throw DataException('服务器返回错误（HTTP ${r.statusCode}）');
      }
      return r;
    } on TimeoutException {
      throw DataException('请求超时，请检查网络后重试');
    } on SocketException {
      throw DataException('网络连接失败，请检查网络');
    } on http.ClientException catch (e) {
      throw DataException('网络请求失败：${e.message}');
    }
  }

  String _unescape(String s) => s.replaceAllMapped(
        RegExp(r'\\u([0-9a-fA-F]{4})'),
        (m) => String.fromCharCode(int.parse(m[1]!, radix: 16)),
      );

  @override
  Future<List<Security>> search(String query) async {
    final uri = Uri.https(
        'smartbox.gtimg.cn', '/s3/', {'v': '2', 'q': query, 't': 'all'});
    final r = await _get(uri, const Duration(seconds: 10));
    final body = utf8.decode(r.bodyBytes, allowMalformed: true);
    final m = RegExp(r'v_hint="([^"]*)"').firstMatch(body);
    if (m == null) throw DataException('搜索结果格式无法识别');
    final raw = _unescape(m.group(1)!);
    if (raw.isEmpty || raw == 'N/A') return [];
    final out = <Security>[];
    final seen = <String>{};
    for (final item in raw.split('^')) {
      final p = item.split('~');
      if (p.length < 3) continue;
      final market = p[0];
      final digits = p[1];
      final nm = p[2];
      String code;
      if (market == 'us') {
        code = 'us${digits.toUpperCase()}';
      } else if (market == 'sh' || market == 'sz' || market == 'bj') {
        code = '$market$digits';
      } else {
        continue; // HK etc. not supported yet
      }
      if (seen.add(code)) out.add(Security(code: code, name: nm));
      if (out.length >= 20) break;
    }
    return out;
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    final endpoint = s.isUs ? 'usfqkline' : 'fqkline';
    final adj = adjusted ? 'qfq' : '';
    final uri = Uri.parse(
        'https://web.ifzq.gtimg.cn/appstock/app/$endpoint/get?param=${s.code},day,,,$_barCount,$adj');
    final r = await _get(uri, const Duration(seconds: 15));

    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('行情数据格式错误');
    }
    if (j is! Map || j['data'] is! Map) {
      throw DataException('该代码没有可用的日线行情（${s.code}）');
    }
    final data = j['data'] as Map;
    dynamic node = data[s.code];
    if (node == null && data.isNotEmpty) node = data.values.first;
    if (node is! Map) throw DataException('该代码没有可用的日线行情（${s.code}）');

    List? rows;
    var label = '不复权';
    if (adjusted && node['qfqday'] is List) {
      rows = node['qfqday'] as List;
      label = '前复权';
    } else if (node['day'] is List) {
      rows = node['day'] as List;
    } else if (node['qfqday'] is List) {
      rows = node['qfqday'] as List;
      label = '前复权';
    }
    if (rows == null || rows.isEmpty) {
      throw DataException('该代码没有可用的日线行情（${s.code}）');
    }

    final byDate = <String, Bar>{};
    var dec = 2;
    for (final row in rows) {
      if (row is! List || row.length < 3) continue;
      final date = row[0].toString();
      final closeStr = row[2].toString();
      final close = double.tryParse(closeStr);
      if (close == null || !RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date)) {
        continue;
      }
      final dot = closeStr.indexOf('.');
      if (dot >= 0) {
        final d = closeStr.length - dot - 1;
        if (d > dec) dec = d;
      }
      byDate[date] = Bar(date, close);
    }
    if (byDate.isEmpty) throw DataException('行情数据为空或无法解析');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    return PriceSeries(
      security: s,
      bars: bars,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: label,
      decimals: dec > 4 ? 4 : dec,
    );
  }
}
