/// Plain data models shared by the data layer, chart layer and UI.

class Security {
  const Security({required this.code, required this.name});

  /// Tencent-style code: sh600519, sz000001, sh000001 (index), usAAPL.OQ ...
  final String code;
  final String name;

  bool get isUs => code.startsWith('us');
  String get marketLabel => isUs ? '美股' : 'A股';
  String get shortCode => code.replaceFirst(RegExp(r'^(sh|sz|bj|us)'), '');
}

/// One daily bar. [date] is "yyyy-MM-dd" exactly as delivered by the source.
class Bar {
  const Bar(this.date, this.close);
  final String date;
  final double close;
}

class PriceSeries {
  PriceSeries({
    required this.security,
    required this.bars,
    required this.fetchedAt,
    required this.source,
    required this.adjustment,
    required this.decimals,
  });

  final Security security;
  final List<Bar> bars;
  final DateTime fetchedAt;
  final String source;

  /// '不复权' or '前复权' - what the prices really are.
  final String adjustment;

  /// Number of decimals to show for this security's prices.
  final int decimals;

  String get lastDate => bars.last.date;
}

class DataException implements Exception {
  DataException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Quick-pick indices shown in the search sheet.
const List<Security> kPresets = [
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'sz399001', name: '深证成指'),
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000300', name: '沪深300'),
  Security(code: 'sh000688', name: '科创50'),
  Security(code: 'us.INX', name: '标普500'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
];
