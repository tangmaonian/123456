import 'models.dart';

/// Abstraction over a market-data provider. The chart and UI only depend on
/// this interface, so the provider can be replaced without touching them.
abstract class MarketDataSource {
  String get name;

  Future<List<Security>> search(String query);

  /// Daily history, oldest first. Throws [DataException] on any failure.
  Future<PriceSeries> history(Security security, {required bool adjusted});
}
