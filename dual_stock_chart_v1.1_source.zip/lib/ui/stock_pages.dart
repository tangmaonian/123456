import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/history_store.dart';
import '../data/http_util.dart';
import '../data/market_data_source.dart';
import '../data/models.dart';
import '../data/tencent_source.dart';

const Color _stockRed = Color(0xFFE53935);
const Color _stockGreen = Color(0xFF159447);
const Color _headerRed = Color(0xFFE53935);

class _WatchData {
  const _WatchData({this.quote, this.minute, this.history});
  final Quote? quote;
  final MinuteSeries? minute;
  final PriceSeries? history;
}

class WatchlistScreen extends StatefulWidget {
  const WatchlistScreen({
    super.key,
    required this.watch,
    required this.source,
    this.selected,
  });
  final List<Security> watch;
  final MarketDataSource source;
  final Security? selected;

  @override
  State<WatchlistScreen> createState() => _WatchlistScreenState();
}

class _WatchlistScreenState extends State<WatchlistScreen> {
  final Map<String, Future<_WatchData>> _futures = {};
  Security? _selected;

  @override
  void initState() {
    super.initState();
    _selected = widget.selected ?? (widget.watch.isEmpty ? null : widget.watch.first);
  }

  Future<_WatchData> _load(Security security) async {
    Quote? quote;
    MinuteSeries? minute;
    PriceSeries? history;
    try {
      quote = await widget.source.quote(security).timeout(const Duration(seconds: 12));
    } catch (_) {
      try {
        quote = await TencentDataSource().quote(security).timeout(const Duration(seconds: 12));
      } catch (_) {}
    }
    try {
      minute = await _fetchMinute(security).timeout(const Duration(seconds: 15));
    } catch (_) {}
    if (minute == null) {
      try {
        history = await HistoryStore().load(security, adjusted: true);
      } catch (_) {}
    }
    return _WatchData(quote: quote, minute: minute, history: history);
  }

  Future<_WatchData> _future(Security s) =>
      _futures.putIfAbsent(s.code, () => _load(s));

  void _refresh() {
    setState(() => _futures.clear());
  }

  void _showSelectedMinute() {
    final s = _selected;
    if (s == null) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => StockDetailScreen(
        security: s,
        source: widget.source,
        watch: widget.watch,
        openedFromWatchlist: true,
      ),
    ));
  }

  void _goDual() => Navigator.of(context).popUntil((r) => r.isFirst);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: _headerRed,
        foregroundColor: Colors.white,
        title: const Text('自选股行情', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        actions: [
          TextButton(onPressed: _goDual, child: const Text('双线', style: TextStyle(color: Colors.white))),
          TextButton(onPressed: _showSelectedMinute, child: const Text('分时', style: TextStyle(color: Colors.white))),
          TextButton(
            onPressed: _refresh,
            child: const Text('行情', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: widget.watch.isEmpty
          ? const Center(child: Text('自选股列表为空\n请先回到双线分析界面，点击 ☆ 添加股票', textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54, height: 1.8)))
          : Column(
              children: [
                Container(
                  height: 34,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  color: const Color(0xFFF5F5F5),
                  child: const Row(children: [
                    Expanded(flex: 5, child: Text('名称 / 代码', style: TextStyle(fontSize: 11, color: Colors.black54))),
                    Expanded(flex: 3, child: Text('分时走势', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black54))),
                    Expanded(flex: 3, child: Text('最新价', textAlign: TextAlign.right, style: TextStyle(fontSize: 11, color: Colors.black54))),
                    Expanded(flex: 3, child: Text('涨跌幅', textAlign: TextAlign.right, style: TextStyle(fontSize: 11, color: Colors.black54))),
                  ]),
                ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () async => _refresh(),
                    child: ListView.separated(
                      itemCount: widget.watch.length,
                      separatorBuilder: (_, __) => const Divider(height: 1, indent: 12, endIndent: 12),
                      itemBuilder: (context, index) {
                        final s = widget.watch[index];
                        return FutureBuilder<_WatchData>(
                          future: _future(s),
                          builder: (context, snapshot) {
                            final data = snapshot.data;
                            final q = data?.quote;
                            final minute = data?.minute;
                            final history = data?.history;
                            final change = q != null && q.prevClose != null && q.prevClose! > 0
                                ? (q.price - q.prevClose!) / q.prevClose! * 100
                                : null;
                            final up = change == null ? false : change >= 0;
                            final color = change == null ? Colors.black54 : (up ? _stockRed : _stockGreen);
                            final decimals = 2;
                            final preview = minute != null
                                ? minute.points.map((p) => p.price).toList()
                                : (history?.bars.map((b) => b.close).toList() ?? const <double>[]);
                            final previewUp = preview.length > 1 && preview.last >= preview.first;
                            return InkWell(
                              onTap: () {
                                setState(() => _selected = s);
                                Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => StockDetailScreen(
                                    security: s, source: widget.source, watch: widget.watch,
                                    openedFromWatchlist: true,
                                  ),
                                ));
                              },
                              onLongPress: () => setState(() => _selected = s),
                              child: Container(
                                color: _selected?.code == s.code ? const Color(0xFFFFF7F6) : Colors.white,
                                height: 76,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                                  child: Row(children: [
                                    Expanded(flex: 5, child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                                        const SizedBox(height: 3),
                                        Text('${s.shortCode}  ${s.marketLabel}', style: const TextStyle(fontSize: 10, color: Colors.black45)),
                                      ],
                                    )),
                                    Expanded(flex: 3, child: SizedBox(
                                      height: 38,
                                      child: preview.length > 1
                                          ? CustomPaint(painter: _SparkPainter(preview, previewUp ? _stockRed : _stockGreen))
                                          : Center(child: snapshot.connectionState == ConnectionState.waiting
                                              ? const SizedBox(width: 13, height: 13, child: CircularProgressIndicator(strokeWidth: 1.5))
                                              : const Text('--', style: TextStyle(color: Colors.black26))),
                                    )),
                                    Expanded(flex: 3, child: Text(q == null ? '--' : q.price.toStringAsFixed(decimals),
                                      textAlign: TextAlign.right, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color))),
                                    Expanded(flex: 3, child: Text(change == null ? '--' : '${change >= 0 ? '+' : ''}${change.toStringAsFixed(2)}%',
                                      textAlign: TextAlign.right, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color))),
                                  ]),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class MinutePoint {
  const MinutePoint({required this.time, required this.price, required this.average, required this.volume});
  final String time;
  final double price;
  final double average;
  final double volume;
}

class MinuteSeries {
  const MinuteSeries({required this.date, required this.points});
  final String date;
  final List<MinutePoint> points;
}

class DailyCandle {
  const DailyCandle({required this.date, required this.open, required this.close,
    required this.high, required this.low, required this.volume});
  final String date;
  final double open;
  final double close;
  final double high;
  final double low;
  final double volume;
}

Future<List<DailyCandle>> _fetchDailyCandles(Security security) async {
  final uri = Uri.parse('https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=${security.code},day,,,180,qfq');
  final response = await httpGet(uri, headers: const {'Referer': 'https://gu.qq.com/'});
  final root = jsonDecode(utf8.decode(response.bodyBytes, allowMalformed: true));
  final data = root is Map ? root['data'] : null;
  final node = data is Map ? data[security.code] : null;
  if (node is! Map) throw DataException('没有可用的日线K线数据');
  final rows = node['qfqday'] is List ? node['qfqday'] as List : node['day'];
  if (rows is! List || rows.isEmpty) throw DataException('没有可用的日线K线数据');
  final result = <DailyCandle>[];
  for (final row in rows) {
    if (row is! List || row.length < 6) continue;
    final o = double.tryParse(row[1].toString());
    final c = double.tryParse(row[2].toString());
    final h = double.tryParse(row[3].toString());
    final l = double.tryParse(row[4].toString());
    final v = double.tryParse(row[5].toString()) ?? 0.0;
    if (o == null || c == null || h == null || l == null) continue;
    result.add(DailyCandle(date: row[0].toString(), open: o, close: c,
      high: h, low: l, volume: v));
  }
  if (result.isEmpty) throw DataException('日线K线数据为空或无法解析');
  return result;
}

Future<MinuteSeries> _fetchMinute(Security security) async {
  final uri = Uri.https('web.ifzq.gtimg.cn', '/appstock/app/minute/query', {'code': security.code});
  final response = await httpGet(uri, headers: const {'Referer': 'https://gu.qq.com/'}, timeout: const Duration(seconds: 15));
  dynamic root;
  try {
    root = jsonDecode(utf8.decode(response.bodyBytes, allowMalformed: true));
  } catch (_) {
    throw DataException('分时数据格式无法识别');
  }
  final data = root is Map ? root['data'] : null;
  final node = data is Map ? data[security.code] : null;
  final inner = node is Map ? node['data'] : null;
  final raw = inner is Map ? inner['data'] : null;
  final date = inner is Map ? (inner['date']?.toString() ?? '') : '';
  if (raw is! List || raw.isEmpty) throw DataException('当前没有可用的分时数据');
  final points = <MinutePoint>[];
  for (final item in raw) {
    final fields = item.toString().trim().split(RegExp(r'\s+'));
    if (fields.length < 2) continue;
    final price = double.tryParse(fields[1]);
    if (price == null || price <= 0) continue;
    final average = fields.length > 2 ? (double.tryParse(fields[2]) ?? price) : price;
    final volume = fields.length > 3 ? (double.tryParse(fields[3]) ?? 0.0) : 0.0;
    points.add(MinutePoint(time: fields[0], price: price, average: average, volume: volume));
  }
  if (points.isEmpty) throw DataException('分时数据为空或无法解析');
  return MinuteSeries(date: date, points: points);
}

class StockDetailScreen extends StatefulWidget {
  const StockDetailScreen({
    super.key,
    required this.security,
    required this.source,
    this.watch = const [],
    this.openedFromWatchlist = false,
  });
  final Security security;
  final MarketDataSource source;
  final List<Security> watch;
  final bool openedFromWatchlist;

  @override
  State<StockDetailScreen> createState() => _StockDetailScreenState();
}

class _StockDetailScreenState extends State<StockDetailScreen> {
  final TencentDataSource _tencent = TencentDataSource();
  Quote? _quote;
  MinuteSeries? _minute;
  String? _minuteError;
  bool _loading = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _loadMinuteOnly());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    await Future.wait([_loadMinuteOnly(), _loadQuote()]);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadQuote() async {
    try {
      final q = await widget.source.quote(widget.security);
      if (mounted) setState(() => _quote = q);
    } catch (_) {
      try {
        final q = await _tencent.quote(widget.security);
        if (mounted) setState(() => _quote = q);
      } catch (_) {}
    }
  }

  Future<void> _loadMinuteOnly() async {
    try {
      final m = await _fetchMinute(widget.security);
      if (mounted) setState(() { _minute = m; _minuteError = null; });
    } catch (e) {
      if (mounted) setState(() => _minuteError = e.toString());
    }
  }

  void _goDual() => Navigator.of(context).popUntil((r) => r.isFirst);

  void _goMarket() {
    if (widget.openedFromWatchlist && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(
      settings: const RouteSettings(name: '/watchlist'),
      builder: (_) => WatchlistScreen(
        watch: widget.watch,
        source: widget.source,
        selected: widget.security,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final q = _quote;
    final change = q != null && q.prevClose != null && q.prevClose! > 0
        ? (q.price - q.prevClose!) / q.prevClose! * 100 : null;
    final color = change == null ? Colors.black54 : (change >= 0 ? _stockRed : _stockGreen);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: _headerRed,
        foregroundColor: Colors.white,
        title: const Text('分时图', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        actions: [
          TextButton(onPressed: _goDual, child: const Text('双线', style: TextStyle(color: Colors.white))),
          TextButton(onPressed: () {}, child: const Text('分时', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
          TextButton(onPressed: _goMarket, child: const Text('行情', style: TextStyle(color: Colors.white))),
        ],
      ),
      body: Column(children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.security.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              Text('${widget.security.shortCode}  ${widget.security.marketLabel}',
                style: const TextStyle(fontSize: 11, color: Colors.black45)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(q == null ? '--' : q.price.toStringAsFixed(2),
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
              Text(change == null ? '--' : '${change >= 0 ? '+' : ''}${change.toStringAsFixed(2)}%',
                style: TextStyle(fontSize: 13, color: color)),
            ]),
            IconButton(tooltip: '刷新', onPressed: _load, icon: const Icon(Icons.refresh, size: 20)),
          ]),
        ),
        const Divider(height: 1),
        Expanded(
          child: _minute == null
              ? Center(child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_minuteError ?? '正在获取分时行情…',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.black54, height: 1.6)),
                ))
              : Padding(
                  padding: const EdgeInsets.all(8),
                  child: CustomPaint(
                    painter: _MinuteChartPainter(_minute!, q?.prevClose),
                    child: const SizedBox.expand(),
                  ),
                ),
        ),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
          child: Row(children: [
            const Text('分时走势 / 成交量', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const Spacer(),
            Text(_minute?.date ?? '', style: const TextStyle(fontSize: 11, color: Colors.black45)),
          ]),
        ),
      ]),
    );
  }
}

class _SparkPainter extends CustomPainter {
  _SparkPainter(this.values, this.color);
  final List<double> values;
  final Color color;
  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2 || size.isEmpty) return;
    final lo = values.reduce((a, b) => a < b ? a : b), hi = values.reduce((a, b) => a > b ? a : b);
    final range = hi - lo == 0 ? 1.0 : hi - lo;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = i / (values.length - 1) * size.width;
      final y = size.height - ((values[i] - lo) / range * (size.height - 4)) - 2;
      if (i == 0) { path.moveTo(x, y); } else { path.lineTo(x, y); }
    }
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.4..strokeCap = StrokeCap.round);
  }
  @override
  bool shouldRepaint(covariant _SparkPainter old) => old.values != values || old.color != color;
}

class _MinuteChartPainter extends CustomPainter {
  _MinuteChartPainter(this.series, this.previousClose);
  final MinuteSeries series;
  final double? previousClose;
  @override
  void paint(Canvas canvas, Size size) {
    if (series.points.isEmpty || size.width <= 0 || size.height <= 0) return;
    const left = 48.0, right = 12.0, top = 18.0, bottom = 24.0;
    final plot = Rect.fromLTRB(left, top, size.width - right, size.height - bottom - 78);
    final vol = Rect.fromLTRB(left, plot.bottom + 18, size.width - right, size.height - bottom);
    final prices = series.points.map((p) => p.price).toList();
    final base = previousClose ?? prices.first;
    var lo = math.min(prices.reduce((a, b) => a < b ? a : b), base);
    var hi = math.max(prices.reduce((a, b) => a > b ? a : b), base);
    final pad = math.max((hi - lo) * .08, base.abs() * .001).toDouble();
    lo -= pad; hi += pad;
    final y = (double v) => plot.bottom - (v - lo) / (hi - lo) * plot.height;
    final grid = Paint()..color = const Color(0xFFEAEAEA)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final yy = plot.top + plot.height * i / 4;
      canvas.drawLine(Offset(plot.left, yy), Offset(plot.right, yy), grid);
      final value = hi - (hi - lo) * i / 4;
      _drawText(canvas, value.toStringAsFixed(2), Offset(2, yy - 7), const TextStyle(fontSize: 9, color: Colors.black54));
    }
    final baseY = y(base);
    canvas.drawLine(Offset(plot.left, baseY), Offset(plot.right, baseY), Paint()..color = Colors.black38..strokeWidth = 1..style = PaintingStyle.stroke);
    final line = Path(), avg = Path();
    for (var i = 0; i < series.points.length; i++) {
      final x = plot.left + (series.points.length == 1 ? 0 : i / (series.points.length - 1) * plot.width);
      final yy = y(series.points[i].price);
      final ay = y(series.points[i].average);
      if (i == 0) { line.moveTo(x, yy); avg.moveTo(x, ay); } else { line.lineTo(x, yy); avg.lineTo(x, ay); }
    }
    canvas.drawPath(line, Paint()..color = _stockRed..strokeWidth = 1.5..style = PaintingStyle.stroke);
    canvas.drawPath(avg, Paint()..color = const Color(0xFFE0A000)..strokeWidth = 1..style = PaintingStyle.stroke);
    final maxVol = math.max(1.0, series.points.map((p) => p.volume).reduce((a, b) => a > b ? a : b));
    final barW = math.max(1.0, plot.width / series.points.length * .65).toDouble();
    for (var i = 0; i < series.points.length; i++) {
      final p = series.points[i];
      final x = vol.left + (series.points.length == 1 ? 0 : i / (series.points.length - 1) * vol.width);
      final h = (p.volume / maxVol) * vol.height;
      final barColor = p.price >= base ? _stockRed : _stockGreen;
      canvas.drawRect(Rect.fromLTWH(x - barW / 2, vol.bottom - h, barW, h), Paint()..color = barColor.withOpacity(.65));
    }
    _drawText(canvas, '09:30', Offset(plot.left, size.height - 15), const TextStyle(fontSize: 9, color: Colors.black45));
    _drawText(canvas, '15:00', Offset(plot.right - 28, size.height - 15), const TextStyle(fontSize: 9, color: Colors.black45));
    _drawText(canvas, '成交量', Offset(2, vol.top + 2), const TextStyle(fontSize: 9, color: Colors.black54));
  }
  @override
  bool shouldRepaint(covariant _MinuteChartPainter old) => old.series != series || old.previousClose != previousClose;
}

class _DailyCandlePainter extends CustomPainter {
  _DailyCandlePainter(this.bars);
  final List<DailyCandle> bars;
  @override
  void paint(Canvas canvas, Size size) {
    if (bars.isEmpty || size.isEmpty) return;
    const left = 48.0, right = 12.0, top = 18.0, bottom = 28.0;
    final priceRect = Rect.fromLTRB(left, top, size.width - right, size.height * .68);
    final volumeRect = Rect.fromLTRB(left, priceRect.bottom + 18, size.width - right, size.height - bottom);
    var lo = bars.map((b) => b.low).reduce((a, b) => a < b ? a : b);
    var hi = bars.map((b) => b.high).reduce((a, b) => a > b ? a : b);
    final pad = math.max((hi - lo) * .06, hi.abs() * .001).toDouble();
    lo -= pad; hi += pad;
    final y = (double v) => priceRect.bottom - (v - lo) / (hi - lo) * priceRect.height;
    final grid = Paint()..color = const Color(0xFFEAEAEA)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final yy = priceRect.top + priceRect.height * i / 4;
      canvas.drawLine(Offset(priceRect.left, yy), Offset(priceRect.right, yy), grid);
      _drawText(canvas, (hi - (hi - lo) * i / 4).toStringAsFixed(2), Offset(2, yy - 7), const TextStyle(fontSize: 9, color: Colors.black54));
    }
    final step = priceRect.width / bars.length;
    final candleW = math.max(1.2, step * .62).toDouble();
    final maxVol = math.max(1.0, bars.map((b) => b.volume).reduce((a, b) => a > b ? a : b));
    for (var i = 0; i < bars.length; i++) {
      final b = bars[i];
      final x = priceRect.left + (i + .5) * step;
      final rising = b.close >= b.open;
      final color = rising ? _stockRed : _stockGreen;
      final paint = Paint()..color = color..strokeWidth = 1;
      canvas.drawLine(Offset(x, y(b.high)), Offset(x, y(b.low)), paint);
      final bodyTop = math.min(y(b.open), y(b.close)).toDouble();
      final bodyBottom = math.max(y(b.open), y(b.close)).toDouble();
      final body = Rect.fromLTRB(x - candleW / 2, bodyTop, x + candleW / 2, math.max(bodyTop + 1, bodyBottom).toDouble());
      if (rising) {
        canvas.drawRect(body, Paint()..color = Colors.white..style = PaintingStyle.fill);
        canvas.drawRect(body, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1);
      } else {
        canvas.drawRect(body, paint);
      }
      final vh = b.volume / maxVol * volumeRect.height;
      canvas.drawRect(Rect.fromLTWH(x - candleW / 2, volumeRect.bottom - vh, candleW, vh), Paint()..color = color.withOpacity(.65));
    }
    _drawText(canvas, '成交量', Offset(2, volumeRect.top + 2), const TextStyle(fontSize: 9, color: Colors.black54));
    _drawText(canvas, bars.first.date, Offset(priceRect.left, size.height - 16), const TextStyle(fontSize: 9, color: Colors.black45));
    _drawText(canvas, bars.last.date, Offset(priceRect.right - 72, size.height - 16), const TextStyle(fontSize: 9, color: Colors.black45));
  }
  @override
  bool shouldRepaint(covariant _DailyCandlePainter old) => old.bars != bars;
}

class _DailyLinePainter extends CustomPainter {
  _DailyLinePainter(this.values);
  final List<double> values;
  @override
  void paint(Canvas canvas, Size size) {
    if (values.length < 2 || size.isEmpty) return;
    const left = 48.0, right = 12.0, top = 18.0, bottom = 28.0;
    final rect = Rect.fromLTRB(left, top, size.width - right, size.height - bottom);
    var lo = values.reduce((a, b) => a < b ? a : b), hi = values.reduce((a, b) => a > b ? a : b);
    final pad = math.max((hi - lo) * .08, hi.abs() * .001).toDouble();
    lo -= pad; hi += pad;
    final grid = Paint()..color = const Color(0xFFEAEAEA)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final yy = rect.top + rect.height * i / 4;
      canvas.drawLine(Offset(rect.left, yy), Offset(rect.right, yy), grid);
      _drawText(canvas, (hi - (hi - lo) * i / 4).toStringAsFixed(2), Offset(2, yy - 7), const TextStyle(fontSize: 9, color: Colors.black54));
    }
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = rect.left + i / (values.length - 1) * rect.width;
      final y = rect.bottom - (values[i] - lo) / (hi - lo) * rect.height;
      if (i == 0) { path.moveTo(x, y); } else { path.lineTo(x, y); }
    }
    canvas.drawPath(path, Paint()..color = _stockRed..strokeWidth = 1.5..style = PaintingStyle.stroke);
  }
  @override
  bool shouldRepaint(covariant _DailyLinePainter old) => old.values != values;
}

void _drawText(Canvas canvas, String text, Offset offset, TextStyle style) {
  final painter = TextPainter(text: TextSpan(text: text, style: style), textDirection: TextDirection.ltr)..layout();
  painter.paint(canvas, offset);
}
