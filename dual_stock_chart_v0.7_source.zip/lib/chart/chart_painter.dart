import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'chart_data.dart';

/// A value axis: linear or logarithmic, with padded bounds.
class AxisScale {
  AxisScale._(this.lo, this.hi, this.log);
  final double lo;
  final double hi;
  final bool log;

  static AxisScale build(double mn, double mx, bool wantLog) {
    if (wantLog && mn > 0) {
      final a = math.log(mn), b = math.log(mx);
      final p = (b - a) < 1e-9 ? 0.01 : (b - a) * 0.08;
      return AxisScale._(math.exp(a - p), math.exp(b + p), true);
    }
    if (mx - mn < 1e-9) {
      final p = mx.abs() * 0.01 + 0.01;
      return AxisScale._(mn - p, mx + p, false);
    }
    final p = (mx - mn) * 0.08;
    return AxisScale._(mn - p, mx + p, false);
  }

  /// 0 at the bottom of the axis, 1 at the top.
  double frac(double v) => log
      ? (math.log(v) - math.log(lo)) / (math.log(hi) - math.log(lo))
      : (v - lo) / (hi - lo);

  List<double> ticks() {
    if (!log) return niceTicks(lo, hi);
    if (hi / lo >= 2.5) {
      const sets = [
        [1.0, 2.0, 5.0],
        [1.0, 3.0],
        [1.0],
      ];
      for (final set in sets) {
        final out = <double>[];
        var k = (math.log(lo) / math.ln10).floor() - 1;
        final kEnd = (math.log(hi) / math.ln10).ceil() + 1;
        for (; k <= kEnd; k++) {
          final base = math.pow(10, k).toDouble();
          for (final m in set) {
            final t = m * base;
            if (t >= lo && t <= hi) out.add(t);
          }
        }
        if (out.length >= 3 && out.length <= 7) return out;
      }
    }
    return niceTicks(lo, hi);
  }
}

/// Draws both curves, axes, crosshair and readout.
///
/// Bar i occupies x-units [i, i+1]; the visible window is [left, left+span].
class ChartPainter extends CustomPainter {
  ChartPainter({
    required this.data,
    required this.left,
    required this.span,
    required this.cursor,
    required this.normalized,
    required this.logScale,
    required this.mainName,
    required this.overName,
    required this.mainDec,
    required this.overDec,
    this.hasOver = true,
    this.invert = false,
  });

  static const double leftMargin = 48;
  static const double rightMargin = 54;
  static const Color mainColor = Colors.black;
  static const Color overColor = Color(0xFFE53935);

  final ChartData data;
  final double left;
  final double span;
  final int cursor; // -1 = crosshair hidden
  final bool normalized;
  final bool logScale;
  final String mainName;
  final String overName;
  final int mainDec;
  final int overDec;
  final bool hasOver;

  /// Inverted price axes (like 文华财经 "反转"): higher prices at the bottom.
  final bool invert;

  TextPainter _tp(String t,
      {Color color = Colors.black87, double size = 11, FontWeight? weight}) {
    return TextPainter(
      text: TextSpan(
          text: t,
          style: TextStyle(color: color, fontSize: size, fontWeight: weight)),
      textDirection: TextDirection.ltr,
    )..layout();
  }

  String _fmt(double t) {
    var s = t.toStringAsFixed(4);
    if (s.contains('.')) {
      s = s.replaceFirst(RegExp(r'0+$'), '');
      s = s.replaceFirst(RegExp(r'\.$'), '');
    }
    return s;
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    final plot = Rect.fromLTRB(
        leftMargin, 6, size.width - rightMargin, size.height - 20);
    final n = data.length;
    if (n == 0) {
      final t = _tp('暂无行情数据', color: Colors.black45, size: 14);
      t.paint(canvas, Offset((size.width - t.width) / 2, size.height / 2));
      return;
    }
    final lo = left.floor().clamp(0, n - 1).toInt();
    final hi = (left + span).ceil().clamp(0, n - 1).toInt();
    double xOf(num i) => plot.left + (i + 0.5 - left) / span * plot.width;

    // ---- value transforms -------------------------------------------------
    var base = -1;
    var mb = 1.0, ob = 1.0;
    if (normalized) {
      base = data.commonBase(lo, hi, cursor);
      if (base >= 0) {
        mb = data.main[base]!;
        ob = data.over[base]!;
      }
    }
    double? mv(int i) {
      final v = data.main[i];
      if (v == null) return null;
      if (!normalized) return v;
      return base < 0 ? null : v / mb * 100;
    }

    double? ov(int i) {
      final v = data.over[i];
      if (v == null) return null;
      if (!normalized) return v;
      return base < 0 ? null : v / ob * 100;
    }

    List<double>? rawRange(List<double? Function(int)> fns) {
      double? mn, mx;
      for (final f in fns) {
        for (var i = lo; i <= hi; i++) {
          final v = f(i);
          if (v == null) continue;
          mn = mn == null ? v : math.min(mn, v);
          mx = mx == null ? v : math.max(mx, v);
        }
      }
      if (mn == null || mx == null) return null;
      return [mn, mx];
    }

    List<double>? rr; // right axis (main, or shared in normalized mode)
    List<double>? lr; // left axis (overlay actual price)
    if (normalized) {
      rr = rawRange([mv, ov]);
    } else {
      rr = rawRange([mv]);
      lr = rawRange([ov]);
    }
    final AxisScale? rs = rr == null ? null : AxisScale.build(rr[0], rr[1], logScale);
    final AxisScale? ls = lr == null ? null : AxisScale.build(lr[0], lr[1], logScale);
    double yOf(double v, AxisScale s) => invert
        ? plot.top + s.frac(v) * plot.height
        : plot.bottom - s.frac(v) * plot.height;

    // ---- grid + axes ------------------------------------------------------
    final gridPaint = Paint()
      ..color = const Color(0xFFE3E7EA)
      ..strokeWidth = 0.7;
    canvas.drawRect(
        plot,
        Paint()
          ..color = const Color(0xFFB8C0C6)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.8);

    void drawAxis(AxisScale s, bool rightSide, Color color) {
      for (final t in s.ticks()) {
        final y = yOf(t, s);
        if (y < plot.top - 1 || y > plot.bottom + 1) continue;
        if (rightSide || rs == null) {
          canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
        }
        final tp = _tp(_fmt(t), color: color, size: 10);
        final x = rightSide ? plot.right + 4 : plot.left - 4 - tp.width;
        tp.paint(canvas, Offset(x, y - tp.height / 2));
      }
    }

    if (rs != null) drawAxis(rs, true, Colors.black87);
    if (ls != null) drawAxis(ls, false, overColor);

    // x-axis labels
    final showMonthOnly = span > 150;
    for (var k = 0; k <= 3; k++) {
      final u = left + span * k / 3;
      final i = (u - 0.5).round().clamp(0, n - 1).toInt();
      final ds = data.dates[i];
      final label = showMonthOnly ? ds.substring(0, 7) : ds.substring(5);
      final tp = _tp(label, color: Colors.black54, size: 10);
      var x = plot.left + plot.width * k / 3 - tp.width / 2;
      x = x.clamp(0.0, size.width - tp.width).toDouble();
      tp.paint(canvas, Offset(x, plot.bottom + 4));
    }

    // ---- curves -----------------------------------------------------------
    canvas.save();
    canvas.clipRect(plot);
    void drawLine(double? Function(int) f, AxisScale? s, Color c, double w) {
      if (s == null) return;
      final path = Path();
      var started = false;
      for (var i = math.max(0, lo - 3); i <= math.min(n - 1, hi + 3); i++) {
        final v = f(i);
        if (v == null) continue; // bridge dates with no data
        final o = Offset(xOf(i), yOf(v, s));
        if (!started) {
          path.moveTo(o.dx, o.dy);
          started = true;
        } else {
          path.lineTo(o.dx, o.dy);
        }
      }
      canvas.drawPath(
          path,
          Paint()
            ..color = c
            ..style = PaintingStyle.stroke
            ..strokeWidth = w
            ..strokeJoin = StrokeJoin.round);
    }

    drawLine(ov, normalized ? rs : ls, overColor, 1.6);
    drawLine(mv, rs, mainColor, 1.8);
    canvas.restore();

    // caption (only when something needs explaining)
    final parts = <String>[];
    if (normalized) {
      parts.add(base >= 0
          ? '归一化（基准日 ${data.dates[base]} = 100，非实际股价）'
          : '可见区间内两只股票没有共同交易日，无法归一化');
    }
    if ((rs?.log ?? false) || (ls?.log ?? false)) parts.add('对数坐标');
    if (invert) parts.add('反转');
    if (parts.isNotEmpty) {
      _tp(parts.join('　'), color: Colors.black45, size: 10)
          .paint(canvas, Offset(plot.left + 4, plot.top + 2));
    }

    // ---- crosshair --------------------------------------------------------
    if (cursor >= 0 && cursor < n) {
      final cx = xOf(cursor);
      final visible = cx >= plot.left && cx <= plot.right;
      final mVal = data.main[cursor];
      final oVal = data.over[cursor];
      final mPlot = mv(cursor);
      final oPlot = ov(cursor);

      if (visible) {
        final cp = Paint()
          ..color = const Color(0xFF455A64)
          ..strokeWidth = 0.9;
        canvas.drawLine(Offset(cx, plot.top), Offset(cx, plot.bottom), cp);

        double? hy;
        if (mPlot != null && rs != null) {
          hy = yOf(mPlot, rs);
        } else if (oPlot != null) {
          final s = normalized ? rs : ls;
          if (s != null) hy = yOf(oPlot, s);
        }
        if (hy != null && hy >= plot.top && hy <= plot.bottom) {
          canvas.drawLine(Offset(plot.left, hy), Offset(plot.right, hy), cp);
        }
        if (mPlot != null && rs != null) {
          final y = yOf(mPlot, rs);
          canvas.drawCircle(Offset(cx, y), 3.5, Paint()..color = mainColor);
          _tag(canvas, size, plot, true, y,
              normalized ? mPlot.toStringAsFixed(2) : mPlot.toStringAsFixed(mainDec), mainColor);
        }
        if (oPlot != null) {
          final s = normalized ? rs : ls;
          if (s != null) {
            final y = yOf(oPlot, s);
            canvas.drawCircle(Offset(cx, y), 3.5, Paint()..color = overColor);
            if (!normalized) {
              _tag(canvas, size, plot, false, y, oPlot.toStringAsFixed(overDec), overColor);
            }
          }
        }
      }

      String line(String name, double? actual, double? norm, int dec) {
        if (actual == null) return '$name  无数据';
        final s = '$name  ${actual.toStringAsFixed(dec)}';
        return normalized && norm != null ? '$s（归一化 ${norm.toStringAsFixed(2)}）' : s;
      }

      final tpDate = _tp(data.dates[cursor], weight: FontWeight.bold);
      final tpMain = _tp('● ${line(mainName, mVal, mPlot, mainDec)}', color: mainColor);
      final tpOver = hasOver
          ? _tp('● ${line(overName, oVal, oPlot, overDec)}', color: overColor)
          : null;
      final w = math.max(tpDate.width,
              math.max(tpMain.width, tpOver?.width ?? 0)) +
          14;
      final h = tpDate.height + tpMain.height + (tpOver?.height ?? 0) + 12;
      final onLeftHalf = (cx - plot.left) < plot.width / 2;
      final bx = onLeftHalf ? plot.right - w - 4 : plot.left + 4;
      final box = RRect.fromRectAndRadius(
          Rect.fromLTWH(bx, plot.top + 18, w, h), const Radius.circular(6));
      canvas.drawRRect(box, Paint()..color = const Color(0xE6FFFFFF));
      canvas.drawRRect(
          box,
          Paint()
            ..color = const Color(0xFF90A4AE)
            ..style = PaintingStyle.stroke);
      var ty = plot.top + 18 + 5;
      tpDate.paint(canvas, Offset(bx + 7, ty));
      ty += tpDate.height + 1;
      tpMain.paint(canvas, Offset(bx + 7, ty));
      ty += tpMain.height + 1;
      tpOver?.paint(canvas, Offset(bx + 7, ty));
    }
  }

  void _tag(Canvas canvas, Size size, Rect plot, bool rightSide, double y, String text, Color bg) {
    final tp = _tp(text, color: Colors.white, size: 10, weight: FontWeight.bold);
    final w = tp.width + 6;
    final x = rightSide
        ? math.min(plot.right + 1, size.width - w)
        : math.max(0.0, plot.left - 1 - w);
    final r = Rect.fromLTWH(x, y - tp.height / 2 - 1, w, tp.height + 2);
    canvas.drawRect(r, Paint()..color = bg);
    tp.paint(canvas, Offset(x + 3, y - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant ChartPainter old) => true;
}
