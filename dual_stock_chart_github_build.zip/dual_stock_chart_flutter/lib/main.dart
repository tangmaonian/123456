import 'dart:math' as math;
import 'package:flutter/material.dart';

void main() => runApp(const DualStockApp());

class DualStockApp extends StatelessWidget {
  const DualStockApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: const Color(0xFF101820),
      colorScheme: const ColorScheme.dark(primary: Colors.redAccent),
    ),
    home: const ChartScreen(),
  );
}

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});
  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final List<String> symbols = ['000001.SH', '600519.SH', '000858.SZ', 'NVDA'];
  int selected = 0;
  double start = 0.62; // visible window start in normalized history
  double span = 0.38;  // visible window width
  double? _gestureStartSpan;
  double? _gestureStart;
  double? _gestureAnchor;
  Offset? _lastFocal;

  late final List<double> overlay = _series(420, 0.0007, 0.018, 17);
  late List<double> main = _series(420, 0.0009, 0.023, selected + 4);

  List<double> _series(int n, double drift, double vol, int seed) {
    final r = math.Random(seed);
    double v = 100;
    return List.generate(n, (i) {
      v *= 1 + drift + (r.nextDouble() - 0.5) * vol;
      return v;
    });
  }

  void _switchStock(int index) {
    setState(() {
      selected = index;
      main = _series(420, 0.0009, 0.023, index + 4);
      // Overlay deliberately remains unchanged.
    });
  }

  void _onScaleStart(ScaleStartDetails d, Size size) {
    _gestureStartSpan = span;
    _gestureStart = start;
    _gestureAnchor = (start + (d.localFocalPoint.dx / size.width) * span)
        .clamp(0.0, 1.0);
    _lastFocal = d.localFocalPoint;
  }

  void _onScaleUpdate(ScaleUpdateDetails d, Size size) {
    if (_gestureStartSpan == null || _gestureStart == null) return;
    setState(() {
      if (d.pointerCount >= 2) {
        // Pinch zoom around the initial focal time anchor.
        final nextSpan = (_gestureStartSpan! / d.scale).clamp(0.025, 1.0);
        final anchor = _gestureAnchor ?? 0.5;
        final focalRatio = (anchor - _gestureStart!) / _gestureStartSpan!;
        span = nextSpan;
        start = (anchor - focalRatio * span).clamp(0.0, 1.0 - span);
      } else {
        // One-finger horizontal drag pans through history.
        final dx = d.focalPointDelta.dx;
        start = (start - dx / size.width * span).clamp(0.0, 1.0 - span);
      }
    });
  }

  void _onScaleEnd(ScaleEndDetails d) {
    _gestureStartSpan = null;
    _gestureStart = null;
    _gestureAnchor = null;
  }

  @override
  Widget build(BuildContext context) {
    final dates = ['半年', '一年', '三年', '全部'];
    return Scaffold(
      appBar: AppBar(
        title: const Text('双线股票分析'),
        actions: [
          IconButton(
            tooltip: '回到最新行情',
            onPressed: () => setState(() { start = 1 - span; }),
            icon: const Icon(Icons.vertical_align_bottom),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
              child: Row(
                children: [
                  Expanded(
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: symbols[selected],
                      items: symbols.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                      onChanged: (v) {
                        if (v != null) _switchStock(symbols.indexOf(v));
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text('收盘线', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            Expanded(
              flex: 9,
              child: LayoutBuilder(builder: (context, constraints) {
                final size = Size(constraints.maxWidth, constraints.maxHeight);
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onScaleStart: (d) => _onScaleStart(d, size),
                  onScaleUpdate: (d) => _onScaleUpdate(d, size),
                  onScaleEnd: _onScaleEnd,
                  child: CustomPaint(
                    size: size,
                    painter: StockPainter(
                      main: main,
                      overlay: overlay,
                      start: start,
                      span: span,
                    ),
                  ),
                );
              }),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  for (final label in dates)
                    TextButton(
                      onPressed: () {
                        final width = switch (label) {
                          '半年' => 0.12,
                          '一年' => 0.24,
                          '三年' => 0.70,
                          _ => 1.0,
                        };
                        setState(() { span = width; start = 1 - width; });
                      },
                      child: Text(label),
                    ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 10),
              child: Text(
                '黑线：当前个股    红线：固定叠加对象    双指缩放 / 单指拖动',
                style: TextStyle(fontSize: 11, color: Colors.white54),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class StockPainter extends CustomPainter {
  StockPainter({
    required this.main,
    required this.overlay,
    required this.start,
    required this.span,
  });
  final List<double> main;
  final List<double> overlay;
  final double start;
  final double span;

  @override
  void paint(Canvas canvas, Size size) {
    final plot = Rect.fromLTWH(12, 14, size.width - 24, size.height - 30);
    final grid = Paint()
      ..color = const Color(0xFF34434E)
      ..strokeWidth = 0.7;
    for (int i = 0; i <= 5; i++) {
      final y = plot.top + plot.height * i / 5;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
    }
    final a = (start * (main.length - 1)).floor().clamp(0, main.length - 2);
    final b = ((start + span) * (main.length - 1)).ceil().clamp(a + 1, main.length - 1);
    final mainSlice = main.sublist(a, b + 1);
    final overlaySlice = overlay.sublist(a, b + 1);

    // Normalize both series to their first visible close, making relative
    // percentage performance comparable even when nominal prices differ.
    final m0 = mainSlice.first;
    final o0 = overlaySlice.first;
    final combined = <double>[
      ...mainSlice.map((v) => (v / m0 - 1) * 100),
      ...overlaySlice.map((v) => (v / o0 - 1) * 100),
    ];
    final minY = combined.reduce(math.min);
    final maxY = combined.reduce(math.max);
    final pad = math.max(1.0, (maxY - minY) * 0.12);
    final low = minY - pad, high = maxY + pad;

    Offset point(int i, double value) {
      final x = plot.left + plot.width * i / (mainSlice.length - 1);
      final y = plot.bottom - (value - low) / (high - low) * plot.height;
      return Offset(x, y);
    }

    void drawSeries(List<double> values, double base, Color color, double width) {
      final p = Path();
      for (int i = 0; i < values.length; i++) {
        final pct = (values[i] / base - 1) * 100;
        final pt = point(i, pct);
        if (i == 0) { p.moveTo(pt.dx, pt.dy); } else { p.lineTo(pt.dx, pt.dy); }
      }
      canvas.drawPath(p, Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round);
    }

    drawSeries(mainSlice, m0, const Color(0xFFE7EDF2), 2.2);
    drawSeries(overlaySlice, o0, const Color(0xFFFF4545), 2.2);

    final text = TextPainter(textDirection: TextDirection.ltr);
    text.text = TextSpan(
      text: '相对涨跌幅（%）',
      style: const TextStyle(color: Colors.white54, fontSize: 10),
    );
    text.layout();
    text.paint(canvas, Offset(plot.left + 2, 0));
  }

  @override
  bool shouldRepaint(covariant StockPainter old) =>
      old.main != main || old.overlay != overlay ||
      old.start != start || old.span != span;
}
