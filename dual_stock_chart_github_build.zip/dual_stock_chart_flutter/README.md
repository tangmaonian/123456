# 双线股票分析 Flutter 原型

## 当前包含
- 深色大图界面，收盘价折线显示
- 当前个股黑白线、固定叠加对象红线
- 切换主股票时叠加序列保持不变
- 单指横向拖动历史窗口
- 双指缩放，并尽量保持初始手势焦点对应的时间位置
- 半年、一年、三年、全部快捷窗口
- 回到最新行情

## 重要限制
本版本使用确定性模拟数据，仅用于验证界面和手势交互；尚未接入通达信、
东方财富、新浪或美股行情 API。不能用于交易决策，也不代表实时行情。

## 不会编程也能尝试生成 APK：GitHub Actions

我已在项目中加入 `.github/workflows/build-apk.yml` 自动构建配置。
你只需把整个项目上传到自己的 GitHub 仓库，GitHub 就会在云端编译 APK。

1. 在 GitHub 注册/登录账号：https://github.com
2. 新建一个仓库（Repository），例如 `dual-stock-chart`。
3. 选择 **Add file → Upload files**，把解压后的项目全部文件上传。
   注意：要上传 `.github/workflows/build-apk.yml`；如果网页看不到 `.github`，
   可先上传其他文件，再用 **Add file → Create new file** 创建该路径。
4. 上传完成后打开仓库的 **Actions** 页面，选择 **Build Android APK**，
   点击 **Run workflow**（如果自动构建已启动，也可以直接点开最新运行记录）。
5. 等待运行成功（绿色勾），打开该次运行记录，在 **Artifacts** 区域下载
   `dual-stock-chart-android-apk`。
6. 解压下载的文件，里面的 `app-release.apk` 就是安装包。将它传到安卓手机，
   点击安装；手机若提示权限，允许该来源安装应用。

## APK 构建说明
云端执行的命令为：

```bash
flutter create . --platforms=android
flutter pub get
flutter build apk --release
```

生成路径：`build/app/outputs/flutter-apk/app-release.apk`。

## 下一阶段
1. 选择并验证合法可用的 A 股免费行情接口。
2. 接入美股数据源，并清楚标记 IEX/延迟/历史数据。
3. 增加数据源设置、请求失败提示和缓存。
4. 对齐两个证券的交易日/时间戳，避免错位比较。
5. 为分钟、日、周、月周期提供各自的历史数据聚合。
