import 'dart:async';

import 'package:flutter/material.dart';

import '../data/market_data_source.dart';
import '../data/models.dart';

/// Bottom sheet with two tabs: 自选 (watchlist) and 搜索 (search / indices).
/// Tap a row to select it; tap the star to add/remove from the watchlist.
class SearchSheet extends StatefulWidget {
  const SearchSheet({
    super.key,
    required this.source,
    required this.title,
    required this.watch,
    required this.onToggleWatch,
  });
  final MarketDataSource source;
  final String title;
  final List<Security> watch;
  final void Function(Security) onToggleWatch;

  @override
  State<SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<SearchSheet> {
  final _controller = TextEditingController();
  Timer? _debounce;
  late List<Security> _watch = List<Security>.of(widget.watch);
  late int _tab = _watch.isEmpty ? 1 : 0;
  List<Security> _results = [];
  bool _loading = false;
  String? _error;
  int _req = 0;
  bool _searched = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  bool _isWatched(Security s) => _watch.any((w) => w.code == s.code);

  void _toggle(Security s) {
    setState(() {
      final i = _watch.indexWhere((w) => w.code == s.code);
      if (i >= 0) {
        _watch.removeAt(i);
      } else {
        _watch.add(s);
      }
    });
    widget.onToggleWatch(s);
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    final text = q.trim();
    if (text.isEmpty) {
      setState(() {
        _results = [];
        _error = null;
        _loading = false;
        _searched = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () => _search(text));
  }

  Future<void> _search(String q) async {
    final id = ++_req;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await widget.source.search(q);
      if (!mounted || id != _req) return;
      setState(() {
        _results = r;
        _loading = false;
        _searched = true;
      });
    } catch (e) {
      if (!mounted || id != _req) return;
      setState(() {
        _results = [];
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Widget _tile(Security s) {
    final watched = _isWatched(s);
    return ListTile(
      dense: true,
      title: Text(s.name),
      subtitle: Text('${s.shortCode}　${s.marketLabel}'),
      trailing: IconButton(
        tooltip: watched ? '移出自选' : '加入自选',
        icon: Icon(watched ? Icons.star : Icons.star_border,
            color: watched ? Colors.amber.shade700 : Colors.black45),
        onPressed: () => _toggle(s),
      ),
      onTap: () => Navigator.pop(context, s),
    );
  }

  Widget _watchTab() {
    if (_watch.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('自选股为空。切到“搜索”，点股票右侧的星标即可加入自选。',
            style: TextStyle(color: Colors.black54)),
      );
    }
    return ListView.builder(
      itemCount: _watch.length,
      itemBuilder: (context, i) => _tile(_watch[i]),
    );
  }

  Widget _searchTab() {
    final showPresets = _controller.text.trim().isEmpty;
    final list = showPresets ? kPresets : _results;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            controller: _controller,
            onChanged: (v) {
              setState(() {});
              _onChanged(v);
            },
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: '输入代码或名称，如 600519、茅台、AAPL',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),
        ),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_error!, style: const TextStyle(color: Colors.red)),
          ),
        if (showPresets)
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 10, 16, 2),
            child: Align(
                alignment: Alignment.centerLeft,
                child: Text('常用指数', style: TextStyle(color: Colors.black54))),
          ),
        if (!showPresets && _searched && _results.isEmpty && _error == null)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('没有找到匹配的股票或指数'),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, i) => _tile(list[i]),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    return Padding(
      padding: EdgeInsets.only(bottom: media.viewInsets.bottom),
      child: SizedBox(
        height: media.size.height * 0.75,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
              child: Row(children: [
                Expanded(
                    child: Text(widget.title,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold))),
                IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Row(children: [
                ChoiceChip(
                  label: Text('自选(${_watch.length})'),
                  selected: _tab == 0,
                  onSelected: (_) => setState(() => _tab = 0),
                ),
                const SizedBox(width: 8),
                ChoiceChip(
                  label: const Text('搜索'),
                  selected: _tab == 1,
                  onSelected: (_) => setState(() => _tab = 1),
                ),
              ]),
            ),
            Expanded(child: _tab == 0 ? _watchTab() : _searchTab()),
          ],
        ),
      ),
    );
  }
}
