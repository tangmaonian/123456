import 'package:flutter/material.dart';

import 'ui/chart_screen.dart';

void main() => runApp(const DualStockApp());

class DualStockApp extends StatelessWidget {
  const DualStockApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: '双线股票分析',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF455A64),
          scaffoldBackgroundColor: Colors.white,
        ),
        home: const ChartScreen(),
      );
}
