import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';

import 'models.dart';

class StoreStats {
  const StoreStats(this.count, this.bytes);
  final int count;
  final int bytes;
}

/// On-device store of daily history, one JSON file per (code, adjustment).
/// Every successful download is saved, so browsed securities stay viewable
/// offline. Unadjusted history is merged with what is already stored, so the
/// saved history keeps growing beyond the window the data source returns.
class HistoryStore {
  static const int _maxBars = 5000;
  static const int _maxFiles = 300;

  Directory? _dir;
  bool _pruned = false;

  Future<Directory?> _ensure() async {
    if (_dir != null) return _dir;
    try {
      final base = await getApplicationDocumentsDirectory();
      final d = Directory('${base.path}/history');
      if (!await d.exists()) await d.create(recursive: true);
      _dir = d;
      if (!_pruned) {
        _pruned = true;
        await _prune(d);
      }
      return d;
    } catch (_) {
      return null;
    }
  }

  String _name(String code, bool adjusted) =>
      '${code.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}_${adjusted ? 'q' : 'n'}.json';

  Future<void> _prune(Directory d) async {
    try {
      final files = <File>[];
      await for (final e in d.list()) {
        if (e is File) files.add(e);
      }
      if (files.length <= _maxFiles) return;
      files.sort((a, b) => a.lastModifiedSync().compareTo(b.lastModifiedSync()));
      for (final f in files.sublist(0, files.length - _maxFiles)) {
        await f.delete();
      }
    } catch (_) {}
  }

  Future<PriceSeries?> load(Security s, {required bool adjusted}) async {
    try {
      final d = await _ensure();
      if (d == null) return null;
      final f = File('${d.path}/${_name(s.code, adjusted)}');
      if (!await f.exists()) return null;
      final j = jsonDecode(await f.readAsString());
      if (j is! Map || j['bars'] is! List) return null;
      final bars = <Bar>[];
      for (final b in j['bars'] as List) {
        if (b is List && b.length == 2 && b[0] is String && b[1] is num) {
          bars.add(Bar(b[0] as String, (b[1] as num).toDouble()));
        }
      }
      if (bars.isEmpty) return null;
      return PriceSeries(
        security: s,
        bars: bars,
        fetchedAt: DateTime.tryParse(j['savedAt']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
        source: j['source']?.toString() ?? '本地',
        adjustment: j['adjustment']?.toString() ?? (adjusted ? '前复权' : '不复权'),
        decimals: j['decimals'] is int ? j['decimals'] as int : 2,
        fromCache: true,
      );
    } catch (_) {
      return null;
    }
  }

  /// Saves valid [fresh] history while preserving previously stored bars.
  /// Empty/invalid provider responses must never erase a usable offline file.
  Future<PriceSeries> saveMerged(PriceSeries fresh, {required bool adjusted}) async {
    final validFresh = fresh.bars
        .where((b) => b.date.isNotEmpty && b.close.isFinite && b.close > 0)
        .toList()
      ..sort((a, b) => a.date.compareTo(b.date));

    PriceSeries? old;
    try {
      old = await load(fresh.security, adjusted: adjusted);
    } catch (_) {}

    if (validFresh.isEmpty) {
      return old ?? fresh;
    }

    var out = fresh;
    try {
      final merged = <String, Bar>{};
      if (old != null) {
        for (final b in old.bars) {
          if (b.date.isNotEmpty && b.close.isFinite && b.close > 0) {
            merged[b.date] = b;
          }
        }
      }
      // New provider values take precedence only for dates actually returned.
      for (final b in validFresh) {
        merged[b.date] = b;
      }
      var bars = merged.values.toList()
        ..sort((a, b) => a.date.compareTo(b.date));
      if (bars.length > _maxBars) {
        bars = bars.sublist(bars.length - _maxBars);
      }
      out = PriceSeries(
        security: fresh.security,
        bars: bars,
        fetchedAt: fresh.fetchedAt,
        source: fresh.source,
        adjustment: fresh.adjustment,
        decimals: old == null
            ? fresh.decimals
            : math.max(fresh.decimals, old.decimals),
      );

      final d = await _ensure();
      if (d == null) return out;
      final f = File('${d.path}/${_name(fresh.security.code, adjusted)}');
      final temp = File('${f.path}.tmp');
      await temp.writeAsString(jsonEncode({
        'v': 1,
        'code': out.security.code,
        'name': out.security.name,
        'source': out.source,
        'adjustment': out.adjustment,
        'decimals': out.decimals,
        'savedAt': out.fetchedAt.toIso8601String(),
        'bars': out.bars.map((b) => [b.date, b.close]).toList(),
      }));
      // Replace only after a complete JSON file has been written.
      await temp.rename(f.path);
    } catch (_) {
      // Saving is best-effort; the fresh data is still shown.
      if (old != null) return old;
    }
    return out;
  }

  Future<StoreStats> stats() async {
    var count = 0, bytes = 0;
    try {
      final d = await _ensure();
      if (d != null) {
        await for (final e in d.list()) {
          if (e is File) {
            count++;
            bytes += await e.length();
          }
        }
      }
    } catch (_) {}
    return StoreStats(count, bytes);
  }

  Future<void> clear() async {
    try {
      final d = await _ensure();
      if (d == null) return;
      await for (final e in d.list()) {
        if (e is File) await e.delete();
      }
    } catch (_) {}
  }
}
