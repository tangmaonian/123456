import 'dart:convert';

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';

/// Yahoo Finance (unofficial public endpoints): US, Hong Kong, A-shares and
/// world indices. NOTE: may be unreachable from mainland China without a
/// foreign network, and Yahoo can rate-limit. Google Finance has no public
/// API, so this is the closest free global alternative.
class YahooDataSource implements MarketDataSource {
  static const Map<String, String> _headers = {
    'Accept': 'application/json',
  };
  static const Map<String, String> _indexToYahoo = {
    'us.INX': '^GSPC',
    'us.IXIC': '^IXIC',
    'us.DJI': '^DJI',
    'hkHSI': '^HSI',
    'hkHSTECH': '^HSTECH',
  };

  @override
  String get id => 'yahoo';
  @override
  String get name => 'Yahoo财经';
  @override
  bool get supportsQuote => true;

  String? _symbol(Security s) {
    final c = s.code;
    final idx = _indexToYahoo[c];
    if (idx != null) return idx;
    if (c.startsWith('yh')) return c.substring(2);
    if (c.startsWith('sh')) return '${c.substring(2)}.SS';
    if (c.startsWith('sz')) return '${c.substring(2)}.SZ';
    if (c.startsWith('bj')) return '${c.substring(2)}.BJ';
    if (c.startsWith('hk')) {
      final d = c.substring(2);
      if (!RegExp(r'^\d{5}$').hasMatch(d)) return null;
      return '${int.parse(d).toString().padLeft(4, '0')}.HK';
    }
    if (c.startsWith('us')) {
      var t = c.substring(2);
      final m = RegExp(r'^(.*)\.(OQ|N|AM|O|PK|OTC)$').firstMatch(t);
      if (m != null) t = m.group(1)!;
      if (t.isEmpty || t.startsWith('.')) return null;
      return t.replaceAll('.', '-');
    }
    return null;
  }

  String _codeFromYahoo(String sym) {
    for (final e in _indexToYahoo.entries) {
      if (e.value == sym) return e.key;
    }
    if (sym.endsWith('.SS')) return 'sh${sym.substring(0, sym.length - 3)}';
    if (sym.endsWith('.SZ')) return 'sz${sym.substring(0, sym.length - 3)}';
    if (sym.endsWith('.BJ')) return 'bj${sym.substring(0, sym.length - 3)}';
    if (sym.endsWith('.HK')) {
      final d = sym.substring(0, sym.length - 3);
      return 'hk${d.padLeft(5, '0')}';
    }
    if (!sym.contains('^') && !sym.contains('=') && !RegExp(r'\.[A-Z]{1,2}$').hasMatch(sym)) {
      return 'us${sym.replaceAll('-', '.')}';
    }
    return 'yh$sym';
  }

  @override
  Future<List<Security>> search(String query) async {
    final uri = Uri.https('query2.finance.yahoo.com', '/v1/finance/search', {
      'q': query,
      'quotesCount': '12',
      'newsCount': '0',
      'lang': 'en-US',
    });
    final r = await httpGet(uri, headers: _headers, timeout: const Duration(seconds: 10));
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('Yahoo搜索结果格式无法识别');
    }
    final quotes = (j is Map) ? j['quotes'] : null;
    if (quotes is! List) return [];
    final out = <Security>[];
    final seen = <String>{};
    for (final q in quotes) {
      if (q is! Map) continue;
      final sym = q['symbol']?.toString();
      final type = q['quoteType']?.toString();
      if (sym == null || sym.isEmpty) continue;
      if (type != 'EQUITY' && type != 'INDEX' && type != 'ETF') continue;
      final nm = (q['shortname'] ?? q['longname'] ?? sym).toString();
      final code = _codeFromYahoo(sym);
      if (seen.add(code)) out.add(Security(code: code, name: nm));
    }
    return out;
  }

  Future<Map> _chart(String sym, String range) async {
    final uri = Uri.https('query1.finance.yahoo.com', '/v8/finance/chart/$sym', {
      'range': range,
      'interval': '1d',
      'includeAdjustedClose': 'true',
    });
    final r = await httpGet(uri, headers: _headers);
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('Yahoo数据格式无法识别');
    }
    final chart = (j is Map) ? j['chart'] : null;
    final res = (chart is Map) ? chart['result'] : null;
    if (res is! List || res.isEmpty || res.first is! Map) {
      throw DataException('Yahoo没有该代码的数据（$sym）');
    }
    return res.first as Map;
  }

  String _two(int v) => v.toString().padLeft(2, '0');

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    final sym = _symbol(s);
    if (sym == null) throw DataException('Yahoo不支持该代码（${s.code}）');
    final r = await _chart(sym, '10y');
    final ts = r['timestamp'];
    final ind = r['indicators'];
    if (ts is! List || ind is! Map) throw DataException('Yahoo没有该代码的日线数据（$sym）');

    List? closes;
    final qs = ind['quote'];
    if (qs is List && qs.isNotEmpty && qs.first is Map) {
      final c = (qs.first as Map)['close'];
      if (c is List) closes = c;
    }
    var usedAdj = false;
    if (adjusted) {
      final adj = ind['adjclose'];
      if (adj is List && adj.isNotEmpty && adj.first is Map) {
        final c = (adj.first as Map)['adjclose'];
        if (c is List) {
          closes = c;
          usedAdj = true;
        }
      }
    }
    if (closes == null) throw DataException('Yahoo没有该代码的收盘价数据（$sym）');

    final meta = r['meta'];
    final off = (meta is Map && meta['gmtoffset'] is num)
        ? (meta['gmtoffset'] as num).toInt()
        : 0;

    final byDate = <String, Bar>{};
    var minPrice = double.infinity;
    final n = ts.length < closes.length ? ts.length : closes.length;
    for (var i = 0; i < n; i++) {
      final t = ts[i];
      final c = closes[i];
      if (t is! num || c is! num) continue;
      final d = DateTime.fromMillisecondsSinceEpoch(
          (t.toInt() + off) * 1000, isUtc: true);
      final date = '${d.year}-${_two(d.month)}-${_two(d.day)}';
      final price = double.parse(c.toDouble().toStringAsFixed(4));
      if (price < minPrice) minPrice = price;
      byDate[date] = Bar(date, price);
    }
    if (byDate.isEmpty) throw DataException('Yahoo日线数据为空（$sym）');
    final bars = byDate.values.toList()..sort((a, b) => a.date.compareTo(b.date));
    return PriceSeries(
      security: s,
      bars: bars,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: usedAdj ? '前复权(含分红)' : '拆股调整价',
      decimals: minPrice < 10 ? 3 : 2,
    );
  }

  @override
  Future<Quote> quote(Security s) async {
    final sym = _symbol(s);
    if (sym == null) throw DataException('Yahoo不支持该代码（${s.code}）');
    final r = await _chart(sym, '1d');
    final m = r['meta'];
    if (m is! Map) throw DataException('Yahoo没有该代码的实时报价');
    final price = (m['regularMarketPrice'] is num)
        ? (m['regularMarketPrice'] as num).toDouble()
        : null;
    final ts = m['regularMarketTime'];
    if (price == null || price <= 0) {
      throw DataException('Yahoo实时报价为空（可能未开盘或停牌）');
    }
    if (ts is! num || ts <= 0) {
      throw DataException('Yahoo实时报价没有时间戳，无法判断新旧');
    }
    // Express the quote time as China time (UTC+8), like the other sources.
    final t = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000, isUtc: true)
        .add(const Duration(hours: 8));
    final prevRaw = m['chartPreviousClose'] ?? m['previousClose'];
    return Quote(
      security: s,
      price: price,
      prevClose: prevRaw is num ? prevRaw.toDouble() : null,
      asOf: '${t.year}-${_two(t.month)}-${_two(t.day)} '
          '${_two(t.hour)}:${_two(t.minute)}:${_two(t.second)}',
      fetchedAt: DateTime.now(),
      source: name,
    );
  }
}
