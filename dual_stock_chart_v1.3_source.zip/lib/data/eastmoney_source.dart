import 'dart:convert';

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';

/// Eastmoney: daily K-line (push2his) and snapshot quote (push2).
/// A-shares and A-share indices. Search reuses Tencent's search box.
class EastmoneyDataSource implements MarketDataSource {
  static const Map<String, String> _headers = {
    'Referer': 'https://quote.eastmoney.com/',
  };
  final TencentDataSource _searcher = TencentDataSource();

  @override
  String get id => 'eastmoney';
  @override
  String get name => '东方财富';
  @override
  bool get supportsQuote => true;

  @override
  Future<List<Security>> search(String query) async {
    final all = await _searcher.search(query);
    return all.where((s) => s.isCn || s.isHk).toList();
  }

  /// secid = market.code ; 1 = Shanghai, 0 = Shenzhen/Beijing.
  String _secid(Security s) {
    if (s.isHk) {
      if (RegExp(r'^hk\d{5}$').hasMatch(s.code)) return '116.${s.shortCode}';
      throw DataException('东方财富源暂不支持该港股指数，请换数据源');
    }
    if (!s.isCn) throw DataException('东方财富源仅支持A股和港股个股，请切换数据源查看美股');
    final market = s.code.startsWith('sh') ? '1' : '0';
    return '$market.${s.shortCode}';
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    final uri = Uri.https('push2his.eastmoney.com', '/api/qt/stock/kline/get', {
      'secid': _secid(s),
      'fields1': 'f1,f2,f3,f4,f5,f6',
      'fields2': 'f51,f52,f53,f54,f55,f56,f57',
      'klt': '101',
      'fqt': adjusted ? '1' : '0',
      'beg': '0',
      'end': '20500101',
      'lmt': '800',
      'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
    });
    final r = await httpGet(uri, headers: _headers);
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('东方财富数据格式无法识别');
    }
    final data = (j is Map) ? j['data'] : null;
    final lines = (data is Map) ? data['klines'] : null;
    if (lines is! List || lines.isEmpty) {
      throw DataException('东方财富没有该代码的日线行情（${s.code}）');
    }
    // each line: "date,open,close,high,low,volume,amount"
    final byDate = <String, Bar>{};
    var dec = 2;
    for (final line in lines) {
      final p = line.toString().split(',');
      if (p.length < 3) continue;
      final c = double.tryParse(p[2]);
      if (c == null || p[0].length < 10) continue;
      final d = decimalsOf(p[2]);
      if (d > dec) dec = d;
      byDate[p[0].substring(0, 10)] = Bar(p[0].substring(0, 10), c);
    }
    if (byDate.isEmpty) throw DataException('东方财富日线数据为空');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    return PriceSeries(
      security: s,
      bars: bars,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: adjusted ? '前复权' : '不复权',
      decimals: dec > 4 ? 4 : dec,
    );
  }

  /// push2 stock/get: f43=latest price, f60=prev close, f86=quote unix time.
  /// With fltt=2 prices come back as plain decimals.
  @override
  Future<Quote> quote(Security s) async {
    final uri = Uri.https('push2.eastmoney.com', '/api/qt/stock/get', {
      'secid': _secid(s),
      'fields': 'f43,f60,f86',
      'fltt': '2',
      'invt': '2',
      'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
    });
    final r = await httpGet(uri,
        headers: _headers, timeout: const Duration(seconds: 10));
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('东方财富实时报价格式无法识别');
    }
    final d = (j is Map) ? j['data'] : null;
    if (d is! Map) throw DataException('东方财富没有该代码的实时报价');
    final price = (d['f43'] is num) ? (d['f43'] as num).toDouble() : null;
    if (price == null || price <= 0) {
      throw DataException('东方财富实时报价为空（可能未开盘或停牌）');
    }
    final ts = d['f86'];
    if (ts is! num || ts <= 0) {
      throw DataException('东方财富实时报价没有时间戳，无法判断新旧');
    }
    final t = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000, isUtc: true)
        .add(const Duration(hours: 8));
    String two(int v) => v.toString().padLeft(2, '0');
    final asOf = '${t.year}-${two(t.month)}-${two(t.day)} '
        '${two(t.hour)}:${two(t.minute)}:${two(t.second)}';
    return Quote(
      security: s,
      price: price,
      prevClose: (d['f60'] is num) ? (d['f60'] as num).toDouble() : null,
      asOf: asOf,
      fetchedAt: DateTime.now(),
      source: name,
    );
  }
}
