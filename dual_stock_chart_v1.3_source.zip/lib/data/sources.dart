import 'eastmoney_source.dart';
import 'market_data_source.dart';
import 'sina_source.dart';
import 'tencent_source.dart';
import 'yahoo_source.dart';

/// All selectable data sources, in the order shown in the picker.
List<MarketDataSource> buildSources() => [
      TencentDataSource(),
      SinaDataSource(),
      EastmoneyDataSource(),
      YahooDataSource(),
    ];
