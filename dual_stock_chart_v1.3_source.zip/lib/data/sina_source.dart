import 'dart:convert';

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';

/// Sina Finance: snapshot quote (hq.sinajs.cn) + daily K-line (json_v2).
/// A-shares and A-share indices only. Search reuses Tencent's search box
/// because Sina's own suggest API returns GBK text Dart cannot decode.
class SinaDataSource implements MarketDataSource {
  static const Map<String, String> _headers = {
    'Referer': 'https://finance.sina.com.cn',
  };
  final TencentDataSource _searcher = TencentDataSource();

  @override
  String get id => 'sina';
  @override
  String get name => '新浪财经';
  @override
  bool get supportsQuote => true;

  @override
  Future<List<Security>> search(String query) async {
    final all = await _searcher.search(query);
    return all.where((s) => s.isCn).toList();
  }

  void _requireCn(Security s) {
    if (!s.isCn) throw DataException('新浪源仅支持A股和A股指数，请切换数据源查看港股/美股');
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    _requireCn(s);
    if (adjusted) {
      throw DataException('新浪源仅提供不复权日线，请切换为“不复权”或换数据源');
    }
    final uri = Uri.parse(
        'https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/'
        'CN_MarketData.getKLineData?symbol=${s.code}&scale=240&ma=no&datalen=800');
    final r = await httpGet(uri, headers: _headers);
    final text = utf8.decode(r.bodyBytes, allowMalformed: true).trim();
    dynamic j;
    try {
      // Sina returns JS-ish JSON with unquoted keys: [{day:"2026-11-13",open:"..",close:".."}]
      final fixed = text.replaceAllMapped(
          RegExp(r'([{,])\s*([A-Za-z_]+)\s*:'), (m) => '${m[1]}"${m[2]}":');
      j = jsonDecode(fixed);
    } on FormatException {
      throw DataException('新浪日线数据格式无法识别');
    }
    if (j is! List || j.isEmpty) {
      throw DataException('新浪没有该代码的日线行情（${s.code}）');
    }
    final byDate = <String, Bar>{};
    var dec = 2;
    for (final row in j) {
      if (row is! Map) continue;
      final date = row['day']?.toString() ?? '';
      final cs = row['close']?.toString() ?? '';
      final c = double.tryParse(cs);
      if (c == null || date.length < 10) continue;
      final d = decimalsOf(cs);
      if (d > dec) dec = d;
      byDate[date.substring(0, 10)] = Bar(date.substring(0, 10), c);
    }
    if (byDate.isEmpty) throw DataException('新浪日线数据为空');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    return PriceSeries(
      security: s,
      bars: bars,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: '不复权',
      decimals: dec > 4 ? 4 : dec,
    );
  }

  /// var hq_str_sh600519="name,open,prevClose,price,high,low,...,date,time,..";
  /// Index [1]=open [2]=prevClose [3]=price; date/time are fields 30/31 for
  /// stocks. For indices the layout is the same up to field 3, and date/time
  /// are located by pattern instead of fixed index.
  @override
  Future<Quote> quote(Security s) async {
    _requireCn(s);
    final uri = Uri.parse('https://hq.sinajs.cn/list=${s.code}');
    final r = await httpGet(uri,
        headers: _headers, timeout: const Duration(seconds: 10));
    final body = latin1.decode(r.bodyBytes);
    final m = RegExp(r'="([^"]*)"').firstMatch(body);
    if (m == null || m.group(1)!.isEmpty) {
      throw DataException('新浪没有该代码的实时报价');
    }
    final f = m.group(1)!.split(',');
    if (f.length < 4) throw DataException('新浪实时报价格式无法识别');
    final price = double.tryParse(f[3]);
    if (price == null || price <= 0) {
      throw DataException('新浪实时报价为空（可能未开盘或停牌）');
    }
    String? date, time;
    for (final x in f) {
      if (date == null && RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(x)) date = x;
      if (time == null && RegExp(r'^\d{2}:\d{2}:\d{2}$').hasMatch(x)) time = x;
    }
    if (date == null) throw DataException('新浪实时报价没有日期，无法判断新旧');
    return Quote(
      security: s,
      price: price,
      prevClose: double.tryParse(f[2]),
      asOf: time == null ? date : '$date $time',
      fetchedAt: DateTime.now(),
      source: name,
    );
  }
}
