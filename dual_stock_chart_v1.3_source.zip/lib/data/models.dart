/// Plain data models shared by the data layer, chart layer and UI.

class Security {
  const Security({required this.code, required this.name});

  /// Tencent-style code: sh600519, sz000001, sh000001 (index), usAAPL.OQ ...
  final String code;
  final String name;

  bool get isUs => code.startsWith('us');
  bool get isHk => code.startsWith('hk');
  /// Symbols that only Yahoo knows (other markets), stored as "yh<symbol>".
  bool get isOther => code.startsWith('yh');
  bool get isCn => code.isNotEmpty && !isUs && !isHk && !isOther;

  /// The empty "no overlay" selection (see [kNoOverlay]).
  bool get isNone => code.isEmpty;

  String get marketLabel =>
      isUs ? '美股' : (isHk ? '港股' : (isOther ? '全球(Yahoo)' : 'A股'));
  String get shortCode => code.replaceFirst(RegExp(r'^(sh|sz|bj|us|hk|yh)'), '');
}

/// One daily bar. [date] is "yyyy-MM-dd" exactly as delivered by the source.
class Bar {
  const Bar(this.date, this.close);
  final String date;
  final double close;
}

class PriceSeries {
  PriceSeries({
    required this.security,
    required this.bars,
    required this.fetchedAt,
    required this.source,
    required this.adjustment,
    required this.decimals,
    this.fromCache = false,
  });

  final Security security;
  final List<Bar> bars;

  /// True when loaded from the on-device store (not fetched just now);
  /// [fetchedAt] is then the time it was saved.
  final bool fromCache;
  final DateTime fetchedAt;
  final String source;

  /// '不复权' or '前复权' - what the prices really are.
  final String adjustment;

  /// Number of decimals to show for this security's prices.
  final int decimals;

  String get lastDate => bars.last.date;
}

/// A live / delayed snapshot price. [asOf] is the timestamp reported by the
/// source (exchange time), NOT the time we fetched it.
/// US Eastern offset from UTC (hours) for a US wall-clock time.
int usEasternOffset(DateTime wall) {
  DateTime nthSunday(int month, int n) {
    var d = DateTime.utc(wall.year, month, 1);
    while (d.weekday != DateTime.sunday) {
      d = d.add(const Duration(days: 1));
    }
    return d.add(Duration(days: 7 * (n - 1)));
  }

  final start = nthSunday(3, 2).add(const Duration(hours: 2));
  final end = nthSunday(11, 1).add(const Duration(hours: 2));
  final w = DateTime.utc(
      wall.year, wall.month, wall.day, wall.hour, wall.minute, wall.second);
  final dst = !w.isBefore(start) && w.isBefore(end);
  return dst ? -4 : -5;
}

class Quote {
  Quote({
    required this.security,
    required this.price,
    required this.prevClose,
    required this.asOf,
    required this.fetchedAt,
    required this.source,
    this.usEastern = false,
  });
  final Security security;
  final bool usEastern; // asOf is US Eastern wall-clock time
  final double price;
  final double? prevClose;
  final String asOf; // "yyyy-MM-dd HH:mm:ss" as reported, may be date only
  final DateTime fetchedAt;
  final String source;

  String get asOfDate => asOf.length >= 10 ? asOf.substring(0, 10) : asOf;

  /// Age of the quote in minutes relative to now, or null if unparseable.
  int? ageMinutes() {
    final t = DateTime.tryParse(asOf.replaceFirst(' ', 'T'));
    if (t == null || asOf.length < 16) return null;
    // China/HK time is UTC+8; US quotes carry US Eastern time.
    final offset = usEastern ? usEasternOffset(t) : 8;
    final utc = DateTime.utc(t.year, t.month, t.day, t.hour, t.minute, t.second)
        .subtract(Duration(hours: offset));
    return DateTime.now().toUtc().difference(utc).inMinutes;
  }
}

class DataException implements Exception {
  DataException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// The blank choice for the overlay slot: nothing is overlaid.
const Security kNoOverlay = Security(code: '', name: '无叠加');

/// Quick-pick indices shown in the search sheet.
const List<Security> kPresets = [
  Security(code: 'sh000001', name: '上证指数'),
  Security(code: 'sz399001', name: '深证成指'),
  Security(code: 'sz399006', name: '创业板指'),
  Security(code: 'sh000300', name: '沪深300'),
  Security(code: 'sh000688', name: '科创50'),
  Security(code: 'us.INX', name: '标普500'),
  Security(code: 'us.IXIC', name: '纳斯达克综合'),
  Security(code: 'us.DJI', name: '道琼斯'),
  Security(code: 'hkHSI', name: '恒生指数'),
  Security(code: 'hkHSTECH', name: '恒生科技指数'),
  // World indices - served by Yahoo Finance (the app switches to it per symbol).
  Security(code: 'yh^N225', name: '日经225（日本）'),
  Security(code: 'yh^TWII', name: '台湾加权指数'),
  Security(code: 'yh^KS11', name: '韩国综合指数'),
  Security(code: 'yh^GDAXI', name: '德国DAX'),
  Security(code: 'yh^FCHI', name: '法国CAC40'),
  Security(code: 'yh^BSESN', name: '印度SENSEX'),
  Security(code: 'yh^NSEI', name: '印度NIFTY50'),
  Security(code: 'yhIMOEX.ME', name: '俄罗斯MOEX'),
  Security(code: 'yhRTSI.ME', name: '俄罗斯RTS'),
  Security(code: 'yh^SET.BK', name: '泰国SET'),
  Security(code: 'yh^VNINDEX.VN', name: '越南VN-Index'),
  Security(code: 'yh^BVSP', name: '巴西圣保罗BOVESPA'),
];
