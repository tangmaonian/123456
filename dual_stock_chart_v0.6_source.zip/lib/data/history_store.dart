import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';

import 'models.dart';

class StoreStats {
  const StoreStats(this.count, this.bytes);
  final int count;
  final int bytes;
}

/// On-device store of daily history, one JSON file per (code, adjustment).
/// Every successful download is saved, so browsed securities stay viewable
/// offline. Unadjusted history is merged with what is already stored, so the
/// saved history keeps growing beyond the window the data source returns.
class HistoryStore {
  static const int _maxBars = 5000;
  static const int _maxFiles = 300;

  Directory? _dir;
  bool _pruned = false;

  Future<Directory?> _ensure() async {
    if (_dir != null) return _dir;
    try {
      final base = await getApplicationDocumentsDirectory();
      final d = Directory('${base.path}/history');
      if (!await d.exists()) await d.create(recursive: true);
      _dir = d;
      if (!_pruned) {
        _pruned = true;
        await _prune(d);
      }
      return d;
    } catch (_) {
      return null;
    }
  }

  String _name(String code, bool adjusted) =>
      '${code.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}_${adjusted ? 'q' : 'n'}.json';

  Future<void> _prune(Directory d) async {
    try {
      final files = <File>[];
      await for (final e in d.list()) {
        if (e is File) files.add(e);
      }
      if (files.length <= _maxFiles) return;
      files.sort((a, b) => a.lastModifiedSync().compareTo(b.lastModifiedSync()));
      for (final f in files.sublist(0, files.length - _maxFiles)) {
        await f.delete();
      }
    } catch (_) {}
  }

  Future<PriceSeries?> load(Security s, {required bool adjusted}) async {
    try {
      final d = await _ensure();
      if (d == null) return null;
      final f = File('${d.path}/${_name(s.code, adjusted)}');
      if (!await f.exists()) return null;
      final j = jsonDecode(await f.readAsString());
      if (j is! Map || j['bars'] is! List) return null;
      final bars = <Bar>[];
      for (final b in j['bars'] as List) {
        if (b is List && b.length == 2 && b[0] is String && b[1] is num) {
          bars.add(Bar(b[0] as String, (b[1] as num).toDouble()));
        }
      }
      if (bars.isEmpty) return null;
      return PriceSeries(
        security: s,
        bars: bars,
        fetchedAt: DateTime.tryParse(j['savedAt']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
        source: j['source']?.toString() ?? '本地',
        adjustment: j['adjustment']?.toString() ?? (adjusted ? '前复权' : '不复权'),
        decimals: j['decimals'] is int ? j['decimals'] as int : 2,
        fromCache: true,
      );
    } catch (_) {
      return null;
    }
  }

  /// Saves [fresh] (merging with stored unadjusted history) and returns the
  /// series to display. Never throws: if saving fails, [fresh] is returned.
  Future<PriceSeries> saveMerged(PriceSeries fresh, {required bool adjusted}) async {
    var out = fresh;
    try {
      final d = await _ensure();
      if (d == null) return fresh;
      if (fresh.adjustment == '不复权') {
        final old = await load(fresh.security, adjusted: adjusted);
        if (old != null && old.adjustment == '不复权') {
          final m = <String, Bar>{};
          for (final b in old.bars) {
            m[b.date] = b;
          }
          for (final b in fresh.bars) {
            m[b.date] = b; // fresh data wins on overlapping dates
          }
          var bars = m.values.toList()..sort((a, b) => a.date.compareTo(b.date));
          if (bars.length > _maxBars) bars = bars.sublist(bars.length - _maxBars);
          out = PriceSeries(
            security: fresh.security,
            bars: bars,
            fetchedAt: fresh.fetchedAt,
            source: fresh.source,
            adjustment: fresh.adjustment,
            decimals: math.max(fresh.decimals, old.decimals),
          );
        }
      }
      final f = File('${d.path}/${_name(fresh.security.code, adjusted)}');
      await f.writeAsString(jsonEncode({
        'v': 1,
        'code': out.security.code,
        'name': out.security.name,
        'source': out.source,
        'adjustment': out.adjustment,
        'decimals': out.decimals,
        'savedAt': out.fetchedAt.toIso8601String(),
        'bars': out.bars.map((b) => [b.date, b.close]).toList(),
      }));
    } catch (_) {
      // Saving is best-effort; the fresh data is still shown.
    }
    return out;
  }

  Future<StoreStats> stats() async {
    var count = 0, bytes = 0;
    try {
      final d = await _ensure();
      if (d != null) {
        await for (final e in d.list()) {
          if (e is File) {
            count++;
            bytes += await e.length();
          }
        }
      }
    } catch (_) {}
    return StoreStats(count, bytes);
  }

  Future<void> clear() async {
    try {
      final d = await _ensure();
      if (d == null) return;
      await for (final e in d.list()) {
        if (e is File) await e.delete();
      }
    } catch (_) {}
  }
}
