import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../chart/chart_data.dart';
import '../chart/chart_painter.dart';
import '../data/history_store.dart';
import '../data/market_data_source.dart';
import '../data/models.dart';
import '../data/sources.dart';
import 'search_sheet.dart';
import 'stock_pages.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});
  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final List<MarketDataSource> _sources = buildSources();
  late MarketDataSource _src = _sources.first;
  Timer? _quoteTimer;
  Timer? _toastTimer;
  SharedPreferences? _prefs;

  // The two selections are fully independent.
  Security _mainSec = const Security(code: 'sh600519', name: '贵州茅台');
  Security _overSec = const Security(code: 'sh000001', name: '上证指数');
  final List<Security> _watch = [];

  PriceSeries? _mainSeries;
  PriceSeries? _overSeries;
  String? _mainErr;
  String? _overErr;
  Quote? _mainQuote;
  Quote? _overQuote;
  String? _mainQErr;
  String? _overQErr;
  bool _mainLoading = false;
  bool _overLoading = false;
  final Map<String, PriceSeries> _cache = {};
  final HistoryStore _store = HistoryStore();
  bool _mainOffline = false;
  bool _overOffline = false;
  bool _downloading = false;
  int _pageMode = 0; // 0=双线, 1=行情, 2=分时

  bool get _noOver => _overSec.isNone;

  ChartData _data = ChartData.empty();
  bool _adjusted = true;
  bool _normalized = false;
  bool _log = false;
  bool _invert = false;

  double _left = 0;
  double _span = 120;
  String? _cursorDate; // null = crosshair hidden
  String? _toast;

  // gesture state
  int _pc = 0;
  int _maxPtr = 0;
  int _axis = 0; // 0 undecided, 1 horizontal pan, 2 vertical swipe
  double _dxTotal = 0;
  double _dyTotal = 0;
  double _span0 = 120;
  double _scale0 = 1;
  double _anchorU = 0;
  double _anchorFrac = 0.5;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  @override
  void dispose() {
    _quoteTimer?.cancel();
    _toastTimer?.cancel();
    super.dispose();
  }

  // ---- persistence ----------------------------------------------------------

  Map<String, String> _enc(Security s) => {'c': s.code, 'n': s.name};
  Security? _dec(dynamic m) {
    if (m is Map && m['c'] is String && m['n'] is String) {
      return Security(code: m['c'] as String, name: m['n'] as String);
    }
    return null;
  }

  Future<void> _restore() async {
    try {
      final p = await SharedPreferences.getInstance();
      _prefs = p;
      final w = p.getString('watch');
      if (w != null) {
        final l = jsonDecode(w);
        if (l is List) {
          for (final e in l) {
            final s = _dec(e);
            if (s != null) _watch.add(s);
          }
        }
      }
      final m = p.getString('main');
      if (m != null) _mainSec = _dec(jsonDecode(m)) ?? _mainSec;
      final o = p.getString('over');
      if (o != null) _overSec = _dec(jsonDecode(o)) ?? _overSec;
      _log = p.getBool('log') ?? false;
      _invert = p.getBool('inv') ?? false;
      _normalized = p.getBool('norm') ?? false;
      // Always start in前复权 mode on each app launch.
    } catch (_) {
      // Fall back to defaults if storage is unavailable.
    }
    if (!mounted) return;
    setState(() {});
    _loadAll();
    // Refresh snapshot prices only (not history) every 30 s.
    _quoteTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _loadQuote(true);
      _loadQuote(false);
    });
  }

  void _save() {
    final p = _prefs;
    if (p == null) return;
    try {
      p.setString('watch', jsonEncode(_watch.map(_enc).toList()));
      p.setString('main', jsonEncode(_enc(_mainSec)));
      p.setString('over', jsonEncode(_enc(_overSec)));
      p.setBool('log', _log);
      p.setBool('inv', _invert);
      p.setBool('norm', _normalized);
      p.setBool('adj', _adjusted);
    } catch (_) {}
  }

  // ---- loading ----------------------------------------------------------------

  double _cl(double v, double a, double b) => v < a ? a : (v > b ? b : v);

  void _loadAll({bool force = false}) {
    if (force) _cache.clear();
    _load(true);
    _load(false);
    _loadQuote(true);
    _loadQuote(false);
  }

  void _applySeries(bool isMain, PriceSeries s) {
    if (isMain) {
      _mainSeries = s;
      _mainErr = null;
      _mainLoading = false;
    } else {
      _overSeries = s;
      _overErr = null;
      _overLoading = false;
    }
    _rebuild();
  }

  MarketDataSource _historySrcFor(Security s) => _src;

  MarketDataSource _srcFor(Security s) => _src;

  bool _current(bool isMain, Security sec, bool adj, MarketDataSource src) =>
      (isMain ? _mainSec : _overSec).code == sec.code &&
      _adjusted == adj &&
      _historySrcFor(sec).id == src.id;

  Future<void> _load(bool isMain) async {
    final sec = isMain ? _mainSec : _overSec;
    final adj = _adjusted;
    final src = _historySrcFor(sec);
    final key = '${src.id}|${sec.code}|$adj';
    if (!isMain && sec.isNone) {
      setState(() {
        _overSeries = null;
        _overErr = null;
        _overLoading = false;
        _overOffline = false;
        _rebuild();
      });
      return;
    }
    if (isMain) {
      _mainOffline = false;
    } else {
      _overOffline = false;
    }
    final cached = _cache[key];
    if (cached != null &&
        DateTime.now().difference(cached.fetchedAt).inMinutes < 5) {
      setState(() => _applySeries(isMain, cached));
      return;
    }
    setState(() {
      if (isMain) {
        _mainLoading = true;
        _mainErr = null;
      } else {
        _overLoading = true;
        _overErr = null;
      }
    });
    // 1) show the locally saved history right away (works offline too)
    final local = await _store.load(sec, adjusted: adj);
    if (!mounted || !_current(isMain, sec, adj, src)) return;
    if (local != null) {
      setState(() {
        _applySeries(isMain, local);
        if (isMain) {
          _mainLoading = true;
        } else {
          _overLoading = true;
        }
      });
    }
    // 2) then fetch fresh data, merge it into the local store and show it
    try {
      final fresh = await src.history(sec, adjusted: adj);
      if (!mounted || !_current(isMain, sec, adj, src)) return;
      // Some providers return an empty series instead of throwing. Treat it
      // as unavailable so the already loaded offline series remains visible.
      if (fresh.bars.isEmpty ||
          !fresh.bars.any((b) => b.date.isNotEmpty && b.close.isFinite && b.close > 0)) {
        throw DataException('${src.name}没有返回有效行情数据');
      }
      final s = await _store.saveMerged(fresh, adjusted: adj);
      if (!mounted || !_current(isMain, sec, adj, src)) return;
      if (_cache.length > 30) _cache.remove(_cache.keys.first);
      _cache[key] = s;
      setState(() => _applySeries(isMain, s));
    } catch (e) {
      if (!mounted || !_current(isMain, sec, adj, src)) return;
      setState(() {
        if (local != null) {
          // keep showing the saved data, clearly marked as offline
          if (isMain) {
            _mainLoading = false;
            _mainOffline = true;
          } else {
            _overLoading = false;
            _overOffline = true;
          }
        } else {
          if (isMain) {
            _mainSeries = null;
            _mainErr = e.toString();
            _mainLoading = false;
          } else {
            _overSeries = null;
            _overErr = e.toString();
            _overLoading = false;
          }
          _rebuild();
        }
      });
    }
  }

  Future<void> _loadQuote(bool isMain) async {
    final sec = isMain ? _mainSec : _overSec;
    final src = _srcFor(sec);
    if (!isMain && sec.isNone) {
      if (_overQuote != null || _overQErr != null) {
        setState(() {
          _overQuote = null;
          _overQErr = null;
        });
      }
      return;
    }
    try {
      final q = await src.quote(sec);
      if (!mounted) return;
      if ((isMain ? _mainSec : _overSec).code != sec.code || _srcFor(sec).id != src.id) {
        return;
      }
      setState(() {
        if (isMain) {
          _mainQuote = q;
          _mainQErr = null;
        } else {
          _overQuote = q;
          _overQErr = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      if ((isMain ? _mainSec : _overSec).code != sec.code || _srcFor(sec).id != src.id) {
        return;
      }
      setState(() {
        if (isMain) {
          _mainQuote = null;
          _mainQErr = e.toString();
        } else {
          _overQuote = null;
          _overQErr = e.toString();
        }
      });
    }
  }

  /// Re-align data after either series changed. Keeps the view span and the
  /// cursor date where possible and jumps to the latest bars.
  void _rebuild() {
    _data = ChartData.align(_mainSeries, _overSeries);
    final n = _data.length;
    if (n == 0) {
      _cursorDate = null;
      return;
    }
    _span = _cl(_span, n < 10 ? n.toDouble() : 10.0, n.toDouble());
    _left = n - _span;
    if (_data.indexOf(_cursorDate) < 0) _cursorDate = null;
  }

  // ---- selection / watchlist ------------------------------------------------

  bool _isWatched(Security s) => _watch.any((w) => w.code == s.code);

  void _toggleWatch(Security s) {
    setState(() {
      final i = _watch.indexWhere((w) => w.code == s.code);
      if (i >= 0) {
        _watch.removeAt(i);
      } else {
        _watch.add(s);
      }
    });
    _save();
  }

  int _importWatch(List<Security> items) {
    var added = 0;
    setState(() {
      for (final s in items) {
        if (!_isWatched(s)) {
          _watch.add(s);
          added++;
        }
      }
    });
    _save();
    return added;
  }

  void _setSecurity(bool isMain, Security s) {
    setState(() {
      if (isMain) {
        _mainSec = s;
        _mainSeries = null;
        _mainQuote = null;
        _mainQErr = null;
        _mainErr = null;
      } else {
        _overSec = s;
        _overSeries = null;
        _overQuote = null;
        _overQErr = null;
        _overErr = null;
      }
      _rebuild();
    });
    _save();
    _load(isMain); // the other series is untouched
    _loadQuote(isMain);
  }

  Future<void> _pick(bool isMain) async {
    final s = await showModalBottomSheet<Security>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => SearchSheet(
        source: _src,
        title: isMain ? '选择主股票（黑线）' : '选择叠加股票/指数（红线）',
        watch: _watch,
        onToggleWatch: _toggleWatch,
        onImportWatch: _importWatch,
        allowNone: !isMain,
      ),
    );
    if (s == null || !mounted) return;
    _setSecurity(isMain, s);
  }

  void _flash(String text) {
    _toastTimer?.cancel();
    setState(() => _toast = text);
    _toastTimer = Timer(const Duration(milliseconds: 1400), () {
      if (mounted) setState(() => _toast = null);
    });
  }

  /// Swipe through the watchlist: changes the black (main) stock only.
  void _stepWatch(int dir) {
    if (_watch.isEmpty) {
      _flash('自选股为空：点底部 ☆ 把当前股票加入自选');
      return;
    }
    final i = _watch.indexWhere((w) => w.code == _mainSec.code);
    int next;
    if (i < 0) {
      next = dir > 0 ? 0 : _watch.length - 1;
    } else {
      next = (i + dir) % _watch.length;
      if (next < 0) next += _watch.length;
    }
    _setSecurity(true, _watch[next]); // no on-chart popup: it would cover the curves
  }

  // ---- gestures ---------------------------------------------------------------

  int _idxAt(double dx, double plotW) {
    final n = _data.length;
    final u = _left + (dx - ChartPainter.leftMargin) / plotW * _span;
    return u.floor().clamp(0, n - 1).toInt();
  }

  void _setCursorAt(double dx, double plotW) {
    if (_data.length == 0) return;
    setState(() => _cursorDate = _data.dates[_idxAt(dx, plotW)]);
  }

  void _toggleCursor() {
    if (_data.length == 0) return;
    setState(() {
      _cursorDate = _cursorDate == null ? _data.dates[_data.length - 1] : null;
    });
  }

  void _onTap(double dx, double plotW) {
    if (_cursorDate != null) {
      setState(() => _cursorDate = null); // tap again hides the crosshair
    } else {
      _setCursorAt(dx, plotW);
    }
  }

  void _reinit(double focalDx, int pc, double scale, double plotW) {
    _pc = pc;
    _span0 = _span;
    _scale0 = scale <= 0 ? 1 : scale;
    final ci = _data.indexOf(_cursorDate);
    var frac = _cl((focalDx - ChartPainter.leftMargin) / plotW, 0, 1);
    if (ci >= 0) {
      final f = (ci + 0.5 - _left) / _span;
      if (f >= 0 && f <= 1) frac = f; // zoom around the selected date
    }
    _anchorFrac = frac;
    _anchorU = _left + frac * _span;
  }

  void _onScaleStart(ScaleStartDetails d, double plotW) {
    _dxTotal = 0;
    _dyTotal = 0;
    _axis = 0;
    _maxPtr = d.pointerCount;
    _reinit(d.localFocalPoint.dx, d.pointerCount, 1, plotW);
    if (d.pointerCount == 1 && _cursorDate != null) {
      _setCursorAt(d.localFocalPoint.dx, plotW);
    }
  }

  void _onScaleUpdate(ScaleUpdateDetails d, double plotW) {
    final n = _data.length;
    if (d.pointerCount > _maxPtr) _maxPtr = d.pointerCount;
    if (d.pointerCount != _pc) {
      _reinit(d.localFocalPoint.dx, d.pointerCount, d.scale, plotW);
    }
    if (d.pointerCount >= 2 && n > 0) {
      final ratio = d.scale / _scale0;
      final minSpan = n < 10 ? n.toDouble() : 10.0;
      final ns = _cl(_span0 / ratio, minSpan, n.toDouble());
      final nl = _cl(_anchorU - _anchorFrac * ns, 0, n - ns);
      setState(() {
        _span = ns;
        _left = nl;
      });
    } else if (_cursorDate != null && n > 0) {
      _setCursorAt(d.localFocalPoint.dx, plotW); // crosshair visible: move it
    } else {
      _dxTotal += d.focalPointDelta.dx;
      _dyTotal += d.focalPointDelta.dy;
      if (_axis == 0 && (_dxTotal.abs() > 10 || _dyTotal.abs() > 10)) {
        _axis = _dyTotal.abs() > _dxTotal.abs() * 1.3 ? 2 : 1;
      }
      if (_axis == 1 && n > 0) {
        final nl = _left - d.focalPointDelta.dx / plotW * _span;
        setState(() => _left = _cl(nl, 0, n - _span));
      }
    }
  }

  void _onScaleEnd(ScaleEndDetails d) {
    if (_axis == 2 && _maxPtr == 1 && _cursorDate == null && _dyTotal.abs() > 60) {
      _stepWatch(_dyTotal < 0 ? 1 : -1); // swipe up = next, down = previous
    }
    _axis = 0;
  }

  void _jumpLatest() => setState(() => _left = _data.length - _span);

  // ---- status / info ----------------------------------------------------------

  String _two(int v) => v.toString().padLeft(2, '0');

  String _fmtTime(DateTime t) =>
      '${t.year}-${_two(t.month)}-${_two(t.day)} ${_two(t.hour)}:${_two(t.minute)}';

  String _statusFor(String tag, Security sec, PriceSeries? s, String? err,
      bool loading, bool offline) {
    if (err != null) return '$tag ${sec.name}：获取失败 - $err';
    if (s == null) return loading ? '$tag ${sec.name}：加载中…' : '$tag ${sec.name}：无数据';
    if (s.fromCache) {
      return '$tag ${sec.name}：本地日线·${s.adjustment}｜最新K线 ${s.lastDate}｜'
          '保存于 ${_fmtTime(s.fetchedAt)}${offline ? '｜网络获取失败，当前为离线数据' : ''}';
    }
    final t = s.fetchedAt;
    return '$tag ${sec.name}：日线·${s.adjustment}｜最新K线 ${s.lastDate}｜'
        '获取于 ${_two(t.hour)}:${_two(t.minute)}:${_two(t.second)}';
  }

  String _quoteText(String tag, Security sec, Quote? q, String? err, int dec) {
    if (err != null) return '$tag ${sec.name} 最新价：获取失败 - $err';
    if (q == null) return '$tag ${sec.name} 最新价：加载中…';
    final age = q.ageMinutes();
    String ageText;
    if (age == null) {
      ageText = '报价时间 ${q.asOf}（无法判断延迟）';
    } else if (age < 0) {
      ageText = '报价时间 ${q.asOf}';
    } else if (age <= 30) {
      ageText = '报价时间 ${q.asOf}｜延迟约 $age 分钟';
    } else if (age < 60 * 48) {
      final h = age ~/ 60;
      ageText = '报价时间 ${q.asOf}｜已过 ${h >= 1 ? '$h 小时' : '$age 分钟'}（非盘中，为最后成交价）';
    } else {
      ageText = '报价时间 ${q.asOf}｜数据已过期';
    }
    return '$tag ${sec.name} 最新价 ${q.price.toStringAsFixed(dec)}｜$ageText';
  }

  Future<void> _showInfo() async {
    final mDec = _mainSeries?.decimals ?? 2;
    final oDec = _overSeries?.decimals ?? 2;
    final st = await _store.stats();
    if (!mounted) return;
    final lines = <String>[
      _statusFor('黑', _mainSec, _mainSeries, _mainErr, _mainLoading, _mainOffline),
      if (!_noOver)
        _statusFor('红', _overSec, _overSeries, _overErr, _overLoading, _overOffline),
      _quoteText('黑', _mainSec, _mainQuote, _mainQErr, mDec),
      if (!_noOver) _quoteText('红', _overSec, _overQuote, _overQErr, oDec),
      '离线数据：已在本机保存 ${st.count} 个品种的历史，约 ${(st.bytes / 1024).round()} KB。下载按钮可保存当前两只股票及全部自选股日线；联网浏览时也会自动保存。无网络时读取本机历史数据。',
      '曲线为日线收盘价；“最新价”是另行获取的报价，以报价时间为准，来自免费公开接口，不保证实时。',
      '操作：点图表显示/隐藏十字光标；十字光标显示时单指拖动移动光标；隐藏时左右拖动平移、上下滑动切换自选股（只换黑线股票）；双指缩放。',
    ];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('数据状态与操作说明'),
        content: SingleChildScrollView(
          child: Text(lines.join('\n\n'), style: const TextStyle(fontSize: 12.5)),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _confirmClear();
            },
            child: const Text('清除离线数据'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('关闭')),
        ],
      ),
    );
  }

  void _confirmClear() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('清除离线数据？'),
        content: const Text('将删除本机保存的全部历史行情，之后需联网重新获取。自选股和设置不受影响。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await _store.clear();
              if (mounted) _flash('离线数据已清除');
            },
            child: const Text('清除'),
          ),
        ],
      ),
    );
  }

  /// Download and save history for every watchlist entry (for offline use).
  Future<void> _downloadWatch() async {
    final targets = <Security>[];
    for (final s in [_mainSec, _overSec, ..._watch]) {
      if (!s.isNone && !targets.any((x) => x.code == s.code)) targets.add(s);
    }
    if (targets.isEmpty) {
      _flash('没有可下载的股票');
      return;
    }
    if (_downloading) return;
    _downloading = true;
    final adj = _adjusted;
    var ok = 0, fail = 0;
    for (var i = 0; i < targets.length; i++) {
      _flash('下载日线并保存到本地 ${i + 1}/${targets.length}…');
      try {
        final h = await _historySrcFor(targets[i]).history(targets[i], adjusted: adj);
        if (h.bars.isEmpty || !h.bars.any((b) => b.close > 0 && b.close.isFinite)) {
          throw DataException('没有有效日线数据');
        }
        await _store.saveMerged(h, adjusted: adj);
        ok++;
      } catch (_) {
        fail++;
      }
      if (!mounted) return;
    }
    _downloading = false;
    _flash('已离线保存 $ok 只${fail > 0 ? '，$fail 只下载失败' : ''}');
  }

  void _setPageMode(int mode) {
    if (!mounted) return;
    setState(() => _pageMode = mode);
    if (mode == 1) {
      // Refresh list content on entry while retaining the selected security.
    } else if (mode == 2) {
      _loadQuote(true);
    }
  }

  void _selectWatchSecurity(Security security) {
    setState(() {
      _mainSec = security;
      _pageMode = 2;
      _mainQuote = null;
      _mainQErr = null;
    });
    _save();
    // Refresh the dual-line series and quote in the background so all three
    // views share the same selected security and are current when revisited.
    _loadAll(force: true);
  }

  void _cycleWatchSecurity(bool next) {
    if (_watch.isEmpty) return;
    var index = _watch.indexWhere((s) => s.code == _mainSec.code);
    if (index < 0) index = 0;
    index = (index + (next ? 1 : -1) + _watch.length) % _watch.length;
    _selectWatchSecurity(_watch[index]);
  }

  Future<void> _openWatchlist() async {
    await Navigator.of(context).push(MaterialPageRoute(
      settings: const RouteSettings(name: '/watchlist'),
      builder: (_) => WatchlistScreen(
        watch: List<Security>.unmodifiable(_watch),
        source: _src,
        selected: _mainSec,
      ),
    ));
  }

  Future<void> _openMinute() async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => StockDetailScreen(
        security: _mainSec,
        source: _src,
        watch: List<Security>.unmodifiable(_watch),
      ),
    ));
  }

  // ---- widgets ----------------------------------------------------------------

  Widget _topPageButton(String label, bool selected, VoidCallback onTap) =>
      TextButton(
        onPressed: onTap,
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          minimumSize: const Size(52, 44),
          tapTargetSize: MaterialTapTargetSize.padded,
          foregroundColor: selected ? const Color(0xFFE53935) : Colors.black87,
        ),
        child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      );

  Widget _selector(bool isMain, bool landscape) {
    final sec = isMain ? _mainSec : _overSec;
    final none = !isMain && sec.isNone;
    final color = isMain
        ? Colors.black
        : (none ? Colors.black26 : const Color(0xFFE53935));
    final loading = isMain ? _mainLoading : _overLoading;
    final q = isMain ? _mainQuote : _overQuote;
    final dec = (isMain ? _mainSeries : _overSeries)?.decimals ?? 2;
    var sub = none
        ? (landscape ? '点此选择' : '点此选择叠加股票/指数')
        : sec.marketLabel;
    if (isMain ? _mainOffline : _overOffline) sub += '·离线';
    if (!none) {
      final age = q?.ageMinutes();
      sub += '  ${q == null ? '--' : q.price.toStringAsFixed(dec)}';
      if (age != null && age > 30) sub += '·非盘中';
    }
    final title = none ? '无叠加' : sec.name;
    final Widget text = landscape
        // Landscape: a single line inside a small box.
        ? Text.rich(
            TextSpan(children: [
              TextSpan(
                  text: title,
                  style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
              TextSpan(
                  text: '  $sub',
                  style: const TextStyle(fontSize: 8, color: Colors.black54)),
            ]),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          )
        : Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
              Text(sub,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 9, color: Colors.black54)),
            ],
          );
    return Expanded(
      child: InkWell(
        onTap: () => _pick(isMain),
        child: Container(
          alignment: Alignment.centerLeft,
          // No fixed height: the box grows with its text (also with a large
          // system font), so nothing overflows the bottom edge.
          padding: EdgeInsets.symmetric(
              horizontal: 8, vertical: landscape ? 2 : 6),
          decoration: BoxDecoration(
            border: Border.all(color: color, width: 1.4),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(children: [
            Expanded(child: text),
            if (loading)
              const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2)),
          ]),
        ),
      ),
    );
  }

  Widget _bar(List<Widget> children) => SizedBox(
        height: 36,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 6),
          children: children,
        ),
      );

  Widget _chip(String label, bool selected, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: ChoiceChip(
          label: Text(label, style: const TextStyle(fontSize: 12)),
          selected: selected,
          visualDensity: VisualDensity.compact,
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          onSelected: (_) => onTap(),
        ),
      );

  Widget _icon(IconData icon, String tip, VoidCallback onTap, {Color? color}) =>
      IconButton(
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        onPressed: onTap,
        icon: Icon(icon, color: color),
      );

  List<String> _issues() {
    final out = <String>[];
    if (_mainErr != null) out.add('黑线 ${_mainSec.name}：$_mainErr');
    if (_overErr != null) out.add('红线 ${_overSec.name}：$_overErr');
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final landscape = MediaQuery.of(context).orientation == Orientation.landscape;
    final cursorIdx = _data.indexOf(_cursorDate);
    final issues = _issues();
    final anyOffline = (_mainOffline && _mainSeries != null) ||
        (_overOffline && _overSeries != null);
    final watched = _isWatched(_mainSec);
    final axisChips = <Widget>[
      _chip('对数', _log, () {
        setState(() => _log = !_log);
        _save();
      }),
      _chip('反转', _invert, () {
        setState(() => _invert = !_invert);
        _save();
      }),
      _chip('归一化', _normalized, () {
        setState(() => _normalized = !_normalized);
        _save();
      }),
      _chip('十字', _cursorDate != null, _toggleCursor),
      _chip('前复权', _adjusted, () {
        setState(() => _adjusted = !_adjusted);
        _save();
        _load(true);
        _load(false);
      }),
    ];
    final toolIcons = <Widget>[
      _icon(watched ? Icons.star : Icons.star_border, watched ? '移出自选' : '加入自选',
          () => _toggleWatch(_mainSec),
          color: watched ? Colors.amber.shade700 : null),
      _icon(Icons.last_page, '回到最新', _jumpLatest),
      _icon(Icons.refresh, '刷新行情', () => _loadAll(force: true)),
      _icon(Icons.download_for_offline_outlined, '下载当前及自选股日线（离线用）', _downloadWatch),
      _icon(Icons.info_outline, '数据状态与说明', _showInfo),
    ];
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(6, landscape ? 2 : 4, 6, landscape ? 2 : 4),
              child: IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _selector(false, landscape),
                    const SizedBox(width: 6),
                    _selector(true, landscape),
                    const SizedBox(width: 3),
                    _topPageButton('双线', _pageMode == 0, () => _setPageMode(0)),
                    _topPageButton('分时', _pageMode == 2, () => _setPageMode(2)),
                    _topPageButton('行情', _pageMode == 1, () => _setPageMode(1)),
                  ],
                ),
              ),
            ),
            Expanded(
              child: _pageMode == 1
                  ? EmbeddedWatchlistPanel(
                      watch: List<Security>.unmodifiable(_watch),
                      source: _src,
                      selected: _mainSec,
                      onSelect: _selectWatchSecurity,
                    )
                  : _pageMode == 2
                      ? GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onVerticalDragEnd: (details) {
                            final velocity = details.primaryVelocity ?? 0;
                            if (velocity.abs() > 120) {
                              _cycleWatchSecurity(velocity < 0);
                            }
                          },
                          child: EmbeddedMinutePanel(
                            key: ValueKey(_mainSec.code),
                            security: _mainSec,
                            source: _srcFor(_mainSec),
                          ),
                        )
                      : LayoutBuilder(builder: (context, cons) {
                final size = Size(cons.maxWidth, cons.maxHeight);
                final plotW = size.width -
                    ChartPainter.leftMargin -
                    ChartPainter.rightMargin -
                    ChartPainter.rightPad;
                return Stack(children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapUp: (d) => _onTap(d.localPosition.dx, plotW),
                    onScaleStart: (d) => _onScaleStart(d, plotW),
                    onScaleUpdate: (d) => _onScaleUpdate(d, plotW),
                    onScaleEnd: _onScaleEnd,
                    child: RepaintBoundary(
                      child: CustomPaint(
                        size: size,
                        painter: ChartPainter(
                          data: _data,
                          left: _left,
                          span: _span,
                          cursor: cursorIdx,
                          normalized: _normalized && !_noOver,
                          hasOver: !_noOver,
                          logScale: _log,
                          invert: _invert,
                          mainName: _mainSec.name,
                          overName: _overSec.name,
                          mainDec: _mainSeries?.decimals ?? 2,
                          overDec: _overSeries?.decimals ?? 2,
                        ),
                      ),
                    ),
                  ),
                  if (_mainLoading || _overLoading)
                    const Positioned(
                      left: 0,
                      right: 0,
                      top: 0,
                      child: IgnorePointer(child: LinearProgressIndicator(minHeight: 2)),
                    ),
                  if (issues.isNotEmpty)
                    Positioned(
                      left: ChartPainter.leftMargin + 6,
                      right: ChartPainter.rightMargin + 6,
                      bottom: 28,
                      child: IgnorePointer(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final t in issues)
                              Text(t,
                                  style: const TextStyle(
                                      color: Colors.red,
                                      fontSize: 12,
                                      backgroundColor: Color(0xE6FFFFFF))),
                          ],
                        ),
                      ),
                    ),
                  if (anyOffline)
                    const Positioned(
                      top: 8,
                      right: ChartPainter.rightMargin + 6,
                      child: IgnorePointer(
                        child: Text('离线',
                            style: TextStyle(
                                color: Color(0xFFEF6C00),
                                fontSize: 13,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  if (_toast != null)
                    Positioned(
                      left: 0,
                      right: 0,
                      top: size.height * 0.35,
                      child: IgnorePointer(
                        child: Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 10),
                            decoration: BoxDecoration(
                              color: const Color(0xCC000000),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(_toast!,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 16)),
                          ),
                        ),
                      ),
                    ),
                ]);
              }),
            ),
            if (landscape)
              _bar([toolIcons.first, ...axisChips, ...toolIcons.sublist(1)])
            else ...[
              _bar(axisChips),
              _bar(toolIcons),
            ],
          ],
        ),
      ),
    );
  }
}
