import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';
import 'eastmoney_source.dart';
import 'yahoo_source.dart';

/// Market-aware provider router. Provider selection is internal and never
/// exposed as a user setting.
class AutoMarketDataSource implements MarketDataSource {
  final TencentDataSource _tx = TencentDataSource();
  final EastmoneyDataSource _em = EastmoneyDataSource();
  final YahooDataSource _yh = YahooDataSource();

  @override
  String get id => 'auto';
  @override
  String get name => '自动';
  @override
  bool get supportsQuote => true;

  bool _global(Security s) => s.isUs || s.isOther ||
      (s.isHk && !RegExp(r'^hk\d{5}$').hasMatch(s.code));
  List<MarketDataSource> _providers(Security s) => _global(s)
      ? <MarketDataSource>[_yh]
      : <MarketDataSource>[_tx, _em];

  Future<T> _try<T>(Security s, Future<T> Function(MarketDataSource) call,
      bool Function(T) valid) async {
    final errors = <String>[];
    for (final p in _providers(s)) {
      try {
        final v = await call(p).timeout(const Duration(seconds: 12));
        if (valid(v)) return v;
        errors.add('${p.name}返回空数据');
      } catch (e) {
        errors.add('${p.name}: $e');
      }
    }
    throw DataException(errors.join('；'));
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) =>
      _try(s, (p) => p.history(s, adjusted: adjusted),
          (v) => v.bars.isNotEmpty && v.bars.any((b) => b.close > 0 && b.close.isFinite));

  @override
  Future<Quote> quote(Security s) => _try(s, (p) => p.quote(s),
      (v) => v.price > 0 && v.price.isFinite);

  @override
  Future<List<Security>> search(String query) async {
    final results = await Future.wait([
      _tx.search(query).catchError((_) => <Security>[]),
      _yh.search(query).catchError((_) => <Security>[]),
    ]);
    final seen = <String>{};
    return [...results[0], ...results[1]].where((s) => seen.add(s.code)).toList();
  }
}
