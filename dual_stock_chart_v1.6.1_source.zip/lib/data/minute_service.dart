import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';

import 'http_util.dart';
import 'models.dart';
import 'yahoo_source.dart';

class MinutePoint {
  const MinutePoint({
    required this.time,
    required this.price,
    required this.average,
    required this.volume,
  });

  /// "HH:MM" in the exchange's local time.
  final String time;
  final double price;

  /// Average price line (volume weighted).
  final double average;

  /// Volume traded in this minute (not cumulative).
  final double volume;
}

class MinuteSeries {
  const MinuteSeries({
    required this.date,
    required this.points,
    this.source = '',
    this.market = 'other',
    this.fromCache = false,
    this.savedAt,
  });

  final String date; // yyyy-MM-dd
  final List<MinutePoint> points;
  final String source;

  /// 'cn' | 'hk' | 'us' | 'other' - decides the trading-session time axis.
  final String market;

  /// True when this is the copy saved on the device (network unavailable).
  final bool fromCache;
  final DateTime? savedAt;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

class _Recent {
  _Recent(this.at, this.series);
  final DateTime at;
  final MinuteSeries series;
}

final Map<String, Future<MinuteSeries>> _inflight = {};
final Map<String, _Recent> _recent = {};

int _active = 0;
final List<Completer<void>> _waiters = [];

Future<T> _gated<T>(Future<T> Function() f) async {
  while (_active >= 3) {
    final c = Completer<void>();
    _waiters.add(c);
    await c.future;
  }
  _active++;
  try {
    return await f();
  } finally {
    _active--;
    if (_waiters.isNotEmpty) _waiters.removeAt(0).complete();
  }
}

/// Intraday (分时) data for [s].
///
/// CN/HK stocks use Tencent first and Eastmoney as a fallback; US stocks and
/// global indices use Yahoo. Tencent 1-minute K-lines are a final CN/HK
/// fallback. A successful
/// result is saved on the device; if every provider fails, the saved copy of
/// the last trading day is returned (marked [MinuteSeries.fromCache]).
/// Only when there is nothing saved either does this throw, with the reason
/// of EACH provider in the message.
Future<MinuteSeries> fetchMinute(Security s, {bool force = false}) {
  final key = s.code;
  if (!force) {
    final r = _recent[key];
    if (r != null && DateTime.now().difference(r.at).inSeconds < 20) {
      return Future.value(r.series);
    }
  }
  final running = _inflight[key];
  if (running != null) return running;
  final f = _gated(() => _fetchMinuteNow(s)).whenComplete(() {
    _inflight.remove(key);
  });
  _inflight[key] = f;
  return f;
}

// ---------------------------------------------------------------------------
// Orchestration
// ---------------------------------------------------------------------------

class _Res {
  _Res.ok(MinuteSeries this.series) : error = null;
  _Res.fail(String this.error) : series = null;
  final MinuteSeries? series;
  final String? error;
}

String _short(Object e) {
  final t = e.toString();
  return t.length > 70 ? '${t.substring(0, 70)}…' : t;
}

Future<_Res> _run(String name, Future<MinuteSeries> Function() f, int secs) async {
  try {
    return _Res.ok(await f().timeout(Duration(seconds: secs)));
  } catch (e) {
    return _Res.fail('$name：${_short(e)}');
  }
}

Future<MinuteSeries?> _firstOk(List<Future<_Res>> fs, List<String> errors) {
  if (fs.isEmpty) return Future.value(null);
  final c = Completer<MinuteSeries?>();
  var left = fs.length;
  for (final f in fs) {
    f.then((r) {
      left--;
      final ok = r.series;
      if (ok != null) {
        if (!c.isCompleted) c.complete(ok);
      } else {
        errors.add(r.error ?? '未知错误');
      }
      if (left == 0 && !c.isCompleted) c.complete(null);
    });
  }
  return c.future;
}

String _marketOf(Security s) =>
    s.isUs ? 'us' : (s.isHk ? 'hk' : (s.isCn ? 'cn' : 'other'));

Future<MinuteSeries> _fetchMinuteNow(Security s) async {
  final errors = <String>[];
  MinuteSeries? result;

  // US equities and global indices are Yahoo-only in the automatic policy.
  final yahooOnly = s.isUs || s.isOther ||
      (s.isHk && !RegExp(r'^hk\d{5}$').hasMatch(s.code));
  if (yahooOnly) {
    final r = await _run('Yahoo', () => _yahooMinute(s), 10);
    result = r.series;
    if (result == null) errors.add(r.error ?? 'Yahoo无分时数据');
  } else {
    // Mainland/HK: Tencent is primary; Eastmoney is tried only if Tencent
    // fails or returns an empty/invalid series.
    final tx = await _run('腾讯', () => _tencentMinute(s), 8);
    result = tx.series;
    if (result == null) errors.add(tx.error ?? '腾讯无分时数据');
    if (result == null && (s.isCn || (s.isHk && RegExp(r'^hk\d{5}$').hasMatch(s.code)))) {
      for (final host in const ['push2.eastmoney.com', 'push2his.eastmoney.com']) {
        final em = await _run('东方财富', () => _eastmoneyMinute(s, host), 8);
        if (em.series != null) {
          result = em.series;
          break;
        }
        errors.add(em.error ?? '东方财富无分时数据');
      }
    }
    // Tencent 1-minute K-lines are a secondary Tencent endpoint, not another
    // selectable data source. Yahoo is not mixed into CN/HK intraday data.
    if (result == null) {
      final mk = await _run('腾讯分钟线', () => _tencentMKline(s), 7);
      result = mk.series;
      if (result == null) errors.add(mk.error ?? '腾讯分钟线无数据');
    }
  }

  if (result != null && result.points.isNotEmpty) {
    _recent[s.code] = _Recent(DateTime.now(), result);
    unawaited(_saveMinute(s, result));
    return result;
  }
  final saved = await loadSavedMinute(s);
  if (saved != null) return saved;
  throw DataException(errors.isEmpty ? '没有取得分时数据' : errors.join('；'));
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const Map<String, String> _txHeaders = {'Referer': 'https://gu.qq.com/'};

dynamic _jsonOf(Uint8List bytes, String who) {
  try {
    return jsonDecode(utf8.decode(bytes, allowMalformed: true));
  } catch (_) {
    throw DataException('$who返回格式无法识别');
  }
}

String _msgOf(dynamic root) {
  if (root is Map && root['msg'] != null && root['msg'].toString().isNotEmpty) {
    return '（${root['msg']}）';
  }
  return '';
}

String _hhmm(String raw) {
  final t = raw.trim();
  if (RegExp(r'^\d{12}$').hasMatch(t)) {
    return '${t.substring(8, 10)}:${t.substring(10, 12)}';
  }
  if (RegExp(r'^\d{4}$').hasMatch(t)) {
    return '${t.substring(0, 2)}:${t.substring(2, 4)}';
  }
  final m = RegExp(r'(\d{1,2}):(\d{2})').firstMatch(t);
  if (m != null) return '${m.group(1)!.padLeft(2, '0')}:${m.group(2)}';
  return t;
}

String _isoDate(String raw) {
  final t = raw.trim();
  if (RegExp(r'^\d{8}').hasMatch(t)) {
    return '${t.substring(0, 4)}-${t.substring(4, 6)}-${t.substring(6, 8)}';
  }
  if (t.length >= 10) return t.substring(0, 10);
  return t;
}

/// Average price from cumulative volume/amount. Volume may be in lots of 100
/// (A-shares) or in shares, so both are tried; if neither is plausible the
/// plain price is used (never a wrong number).
double _avgPrice(double price, double cumVol, double cumAmt) {
  if (cumVol <= 0 || cumAmt <= 0) return price;
  for (final mult in const [1.0, 100.0]) {
    final a = cumAmt / (cumVol * mult);
    if (a > price * 0.5 && a < price * 2) return a;
  }
  return price;
}

// ---------------------------------------------------------------------------
// Provider: Tencent minute/query  (price, cumulative volume, cumulative amount)
// ---------------------------------------------------------------------------

Future<MinuteSeries> _tencentMinute(Security s) async {
  final eps = s.isUs
      ? const ['UsMinute', 'minute']
      : (s.isHk ? const ['hkMinute', 'minute'] : const ['minute']);
  Object? last;
  for (final ep in eps) {
    try {
      return await _tencentMinuteAt(s, ep);
    } catch (e) {
      last = e;
    }
  }
  throw DataException(last?.toString() ?? '没有数据');
}

Future<MinuteSeries> _tencentMinuteAt(Security s, String ep) async {
  final uri = Uri.https('web.ifzq.gtimg.cn', '/appstock/app/$ep/query', {'code': s.code});
  final r = await httpGet(uri, headers: _txHeaders, timeout: const Duration(seconds: 5));
  final root = _jsonOf(r.bodyBytes, '腾讯');
  final data = root is Map ? root['data'] : null;
  if (data is! Map) throw DataException('接口无数据${_msgOf(root)}');
  dynamic node = data[s.code];
  if (node == null && data.isNotEmpty) node = data.values.first;
  final inner = node is Map ? node['data'] : null;
  final raw = inner is Map ? inner['data'] : null;
  final date = inner is Map ? _isoDate(inner['date']?.toString() ?? '') : '';
  if (raw is! List || raw.isEmpty) throw DataException('返回的分时点为空');
  final pts = <MinutePoint>[];
  // Tencent payloads differ by market/endpoint: some provide cumulative
  // volume, others per-minute volume. Detect cumulative series before
  // calculating deltas so per-minute values are not subtracted twice.
  final rawVolumes = <double>[];
  for (final item in raw) {
    final f = item.toString().trim().split(RegExp(r'\s+'));
    if (f.length > 2) rawVolumes.add(double.tryParse(f[2]) ?? 0.0);
  }
  var monotonic = 0;
  for (var i = 1; i < rawVolumes.length; i++) {
    if (rawVolumes[i] >= rawVolumes[i - 1]) monotonic++;
  }
  final cumulative = rawVolumes.length > 3 && monotonic >= (rawVolumes.length - 1) * 0.8;
  var prevCum = 0.0;
  for (final item in raw) {
    final f = item.toString().trim().split(RegExp(r'\s+'));
    if (f.length < 2) continue;
    final price = double.tryParse(f[1]);
    if (price == null || price <= 0) continue;
    final cumVol = f.length > 2 ? (double.tryParse(f[2]) ?? 0.0) : 0.0;
    final cumAmt = f.length > 3 ? (double.tryParse(f[3]) ?? 0.0) : 0.0;
    var vol = cumulative ? cumVol - prevCum : cumVol;
    if (vol < 0 || !vol.isFinite) vol = cumulative ? cumVol : 0.0;
    prevCum = cumVol;
    pts.add(MinutePoint(
      time: _hhmm(f[0]),
      price: price,
      average: _avgPrice(price, cumVol, cumAmt),
      volume: vol,
    ));
  }
  if (pts.isEmpty) throw DataException('分时数据无法解析');
  return MinuteSeries(date: date, points: pts, source: '腾讯', market: _marketOf(s));
}

// ---------------------------------------------------------------------------
// Provider: Eastmoney trends2  (time, open, close, high, low, vol, amt, avg)
// ---------------------------------------------------------------------------

Future<MinuteSeries> _eastmoneyMinute(Security s, String host) async {
  final String secid;
  if (s.isHk) {
    if (!RegExp(r'^hk\d{5}$').hasMatch(s.code)) throw DataException('不支持该港股代码');
    secid = '116.${s.shortCode}';
  } else if (s.isCn) {
    secid = '${s.code.startsWith('sh') ? '1' : '0'}.${s.shortCode}';
  } else {
    throw DataException('不支持该市场');
  }
  final uri = Uri.https(host, '/api/qt/stock/trends2/get', {
    'secid': secid,
    'fields1': 'f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f11,f12,f13',
    'fields2': 'f51,f52,f53,f54,f55,f56,f57,f58',
    'ndays': '1',
    'iscr': '0',
    'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
  });
  final r = await httpGet(uri,
      headers: const {'Referer': 'https://quote.eastmoney.com/'},
      timeout: const Duration(seconds: 6));
  final root = _jsonOf(r.bodyBytes, '东财');
  final data = root is Map ? root['data'] : null;
  final rows = data is Map ? data['trends'] : null;
  if (rows is! List || rows.isEmpty) throw DataException('返回的分时点为空');
  final pts = <MinutePoint>[];
  var date = '';
  for (final row in rows) {
    final f = row.toString().split(',');
    if (f.length < 3) continue;
    final price = double.tryParse(f[2]) ?? double.tryParse(f[1]);
    if (price == null || price <= 0) continue;
    var avg = f.length > 7 ? double.tryParse(f[7]) : null;
    if (avg == null || avg <= price * 0.5 || avg >= price * 2) avg = price;
    final vol = f.length > 5 ? (double.tryParse(f[5]) ?? 0.0) : 0.0;
    final stamp = f[0].trim();
    if (stamp.length >= 10) date = stamp.substring(0, 10);
    pts.add(MinutePoint(time: _hhmm(stamp), price: price, average: avg, volume: vol));
  }
  if (pts.isEmpty) throw DataException('分时数据无法解析');
  return MinuteSeries(date: date, points: pts, source: '东方财富', market: _marketOf(s));
}

// ---------------------------------------------------------------------------
// Fallbacks built from 1/5-minute K-lines (kept to the LAST trading day)
// ---------------------------------------------------------------------------

MinuteSeries _fromBars(
  Security s,
  String source,
  List<List<dynamic>> bars, // [dateIso, hhmm, close, volume]
) {
  if (bars.isEmpty) throw DataException('没有K线数据');
  final lastDate = bars.last[0] as String;
  final pts = <MinutePoint>[];
  var cumVol = 0.0, cumAmt = 0.0;
  for (final b in bars) {
    if (b[0] != lastDate) continue;
    final price = b[2] as double;
    final vol = b[3] as double;
    cumVol += vol;
    cumAmt += price * vol;
    pts.add(MinutePoint(
      time: b[1] as String,
      price: price,
      average: cumVol > 0 ? cumAmt / cumVol : price,
      volume: vol,
    ));
  }
  if (pts.isEmpty) throw DataException('没有K线数据');
  return MinuteSeries(date: lastDate, points: pts, source: source, market: _marketOf(s));
}

Future<MinuteSeries> _tencentMKline(Security s) async {
  final uri = Uri.parse(
      'https://web.ifzq.gtimg.cn/appstock/app/kline/mkline?param=${s.code},m1,,320');
  final r = await httpGet(uri, headers: _txHeaders, timeout: const Duration(seconds: 5));
  final root = _jsonOf(r.bodyBytes, '腾讯分钟线');
  final data = root is Map ? root['data'] : null;
  if (data is! Map) throw DataException('接口无数据${_msgOf(root)}');
  dynamic node = data[s.code];
  if (node == null && data.isNotEmpty) node = data.values.first;
  final rows = node is Map ? node['m1'] : null;
  if (rows is! List || rows.isEmpty) throw DataException('返回为空');
  final bars = <List<dynamic>>[];
  for (final row in rows) {
    if (row is! List || row.length < 6) continue;
    final t = row[0].toString();
    final price = double.tryParse(row[2].toString());
    if (t.length < 12 || price == null || price <= 0) continue;
    bars.add([_isoDate(t), _hhmm(t), price, double.tryParse(row[5].toString()) ?? 0.0]);
  }
  return _fromBars(s, '腾讯1分钟线', bars);
}

Future<MinuteSeries> _yahooMinute(Security s) async {
  final sym = YahooDataSource().symbolFor(s);
  if (sym == null) throw DataException('Yahoo不支持该代码');
  final uri = Uri.https('query1.finance.yahoo.com', '/v8/finance/chart/$sym',
      {'range': '1d', 'interval': '1m'});
  final r = await httpGet(uri,
      headers: const {'Accept': 'application/json'},
      timeout: const Duration(seconds: 5));
  final root = _jsonOf(r.bodyBytes, 'Yahoo');
  final chart = root is Map ? root['chart'] : null;
  final res = chart is Map ? chart['result'] : null;
  if (res is! List || res.isEmpty || res.first is! Map) throw DataException('没有该代码的数据');
  final m = res.first as Map;
  final ts = m['timestamp'];
  final ind = m['indicators'];
  final q = (ind is Map && ind['quote'] is List && (ind['quote'] as List).isNotEmpty)
      ? (ind['quote'] as List).first
      : null;
  if (ts is! List || q is! Map || q['close'] is! List) throw DataException('没有分钟数据');
  final closes = q['close'] as List;
  final vols = q['volume'] is List ? q['volume'] as List : const [];
  final meta = m['meta'];
  final off = (meta is Map && meta['gmtoffset'] is num) ? (meta['gmtoffset'] as num).toInt() : 0;
  final bars = <List<dynamic>>[];
  String two(int v) => v.toString().padLeft(2, '0');
  for (var i = 0; i < ts.length && i < closes.length; i++) {
    final t = ts[i];
    final c = closes[i];
    if (t is! num || c is! num) continue;
    final d = DateTime.fromMillisecondsSinceEpoch((t.toInt() + off) * 1000, isUtc: true);
    final v = (i < vols.length && vols[i] is num) ? (vols[i] as num).toDouble() : 0.0;
    bars.add(['${d.year}-${two(d.month)}-${two(d.day)}', '${two(d.hour)}:${two(d.minute)}', c.toDouble(), v]);
  }
  return _fromBars(s, 'Yahoo', bars);
}

// ---------------------------------------------------------------------------
// Local copy of the last successful intraday series
// ---------------------------------------------------------------------------

Directory? _minDir;

Future<Directory?> _minuteDir() async {
  if (_minDir != null) return _minDir;
  try {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/minute');
    if (!await d.exists()) await d.create(recursive: true);
    _minDir = d;
    return d;
  } catch (_) {
    return null;
  }
}

String _fname(String code) =>
    '${code.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}.json';

Future<void> _saveMinute(Security s, MinuteSeries m) async {
  if (m.points.length < 5) return;
  try {
    final d = await _minuteDir();
    if (d == null) return;
    await File('${d.path}/${_fname(s.code)}').writeAsString(jsonEncode({
      'v': 1,
      'date': m.date,
      'source': m.source,
      'market': m.market,
      'savedAt': DateTime.now().toIso8601String(),
      'points': m.points.map((p) => [p.time, p.price, p.average, p.volume]).toList(),
    }));
  } catch (_) {}
}

/// The copy saved on the device, or null.
Future<MinuteSeries?> loadSavedMinute(Security s) async {
  try {
    final d = await _minuteDir();
    if (d == null) return null;
    final f = File('${d.path}/${_fname(s.code)}');
    if (!await f.exists()) return null;
    final j = jsonDecode(await f.readAsString());
    if (j is! Map || j['points'] is! List) return null;
    final pts = <MinutePoint>[];
    for (final p in j['points'] as List) {
      if (p is List && p.length == 4 && p[0] is String && p[1] is num && p[2] is num && p[3] is num) {
        pts.add(MinutePoint(
          time: p[0] as String,
          price: (p[1] as num).toDouble(),
          average: (p[2] as num).toDouble(),
          volume: (p[3] as num).toDouble(),
        ));
      }
    }
    if (pts.isEmpty) return null;
    return MinuteSeries(
      date: j['date']?.toString() ?? '',
      points: pts,
      source: j['source']?.toString() ?? '本地',
      market: j['market']?.toString() ?? 'other',
      fromCache: true,
      savedAt: DateTime.tryParse(j['savedAt']?.toString() ?? ''),
    );
  } catch (_) {
    return null;
  }
}
