import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

// Reuse connections across quote/minute requests. Some public market-data
// gateways are more reliable with a persistent HTTP session.
final http.Client _httpClient = http.Client();

import 'models.dart';

Future<http.Response> httpGet(Uri uri,
    {Map<String, String>? headers,
    Duration timeout = const Duration(seconds: 15)}) async {
  try {
    final r = await _httpClient
        .get(uri, headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
          'Accept': '*/*',
          'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
          ...?headers,
        })
        .timeout(timeout);
    if (r.statusCode != 200) {
      throw DataException('服务器返回错误（HTTP ${r.statusCode}）');
    }
    return r;
  } on TimeoutException {
    throw DataException('请求超时，请检查网络后重试');
  } on SocketException {
    throw DataException('网络连接失败，请检查网络');
  } on HandshakeException {
    throw DataException('安全连接失败（HTTPS）');
  } on http.ClientException catch (e) {
    throw DataException('网络请求失败：${e.message}');
  }
}

/// Minimal GBK decoder for the few characters we need (stock names).
/// Falls back to latin1 for ASCII; Chinese names from some legacy quote endpoints are GBK, which Dart
/// cannot decode natively, so callers that need names should use a different
/// source (we only decode numeric quote fields).
String decodeAscii(Uint8List bytes) => latin1.decode(bytes);

int decimalsOf(String s) {
  final dot = s.indexOf('.');
  if (dot < 0) return 0;
  return s.length - dot - 1;
}
