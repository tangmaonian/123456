import 'dart:convert';

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';

/// Tencent Finance public endpoints: search, daily bars, snapshot quote.
class TencentDataSource implements MarketDataSource {
  static const int _barCount = 2500;
  static const Map<String, String> _headers = {'Referer': 'https://gu.qq.com/'};

  @override
  String get id => 'tencent';
  @override
  String get name => '腾讯财经';
  @override
  bool get supportsQuote => true;

  String _snippet(List<int> bytes) {
    final s = utf8
        .decode(bytes, allowMalformed: true)
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    return s.length > 80 ? '${s.substring(0, 80)}…' : s;
  }

  String _unescape(String s) => s.replaceAllMapped(
        RegExp(r'\\u([0-9a-fA-F]{4})'),
        (m) => String.fromCharCode(int.parse(m[1]!, radix: 16)),
      );

  @override
  Future<List<Security>> search(String query) async {
    final uri = Uri.https(
        'smartbox.gtimg.cn', '/s3/', {'v': '2', 'q': query, 't': 'all'});
    final r = await httpGet(uri,
        headers: _headers, timeout: const Duration(seconds: 10));
    final body = utf8.decode(r.bodyBytes, allowMalformed: true);
    final m = RegExp(r'v_hint="([^"]*)"').firstMatch(body);
    if (m == null) throw DataException('搜索结果格式无法识别');
    final raw = _unescape(m.group(1)!);
    if (raw.isEmpty || raw == 'N/A') return [];
    final out = <Security>[];
    final seen = <String>{};
    for (final item in raw.split('^')) {
      final p = item.split('~');
      if (p.length < 3) continue;
      final market = p[0];
      final digits = p[1];
      final nm = p[2];
      String code;
      if (market == 'us') {
        code = 'us${digits.toUpperCase()}';
      } else if (market == 'hk') {
        code = 'hk$digits';
      } else if (market == 'sh' || market == 'sz' || market == 'bj') {
        code = '$market$digits';
      } else {
        continue;
      }
      if (seen.add(code)) out.add(Security(code: code, name: nm));
      if (out.length >= 20) break;
    }
    return out;
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) =>
      _history(s, adjusted: adjusted, count: _barCount);

  Future<PriceSeries> _history(Security s,
      {required bool adjusted, required int count}) async {
    final endpoint = s.isUs ? 'usfqkline' : (s.isHk ? 'hkfqkline' : 'fqkline');
    final adj = adjusted ? 'qfq' : '';
    final uri = Uri.parse(
        'https://web.ifzq.gtimg.cn/appstock/app/$endpoint/get?param=${s.code},day,,,$count,$adj');
    final r = await httpGet(uri, headers: _headers);

    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes));
    } on FormatException {
      throw DataException('行情数据格式错误');
    }
    if (j is! Map || j['data'] is! Map) {
      throw DataException(
          '该代码没有可用的日线行情（${s.code}）返回内容：${_snippet(r.bodyBytes)}');
    }
    final data = j['data'] as Map;
    dynamic node = data[s.code];
    if (node == null && data.isNotEmpty) node = data.values.first;
    if (node is! Map) throw DataException('该代码没有可用的日线行情（${s.code}）');

    List? rows;
    var label = '不复权';
    if (adjusted && node['qfqday'] is List) {
      rows = node['qfqday'] as List;
      label = '前复权';
    } else if (node['day'] is List) {
      rows = node['day'] as List;
    } else if (node['qfqday'] is List) {
      rows = node['qfqday'] as List;
      label = '前复权';
    }
    if (rows == null || rows.isEmpty) {
      throw DataException('该代码没有可用的日线行情（${s.code}）');
    }

    final byDate = <String, Bar>{};
    var dec = 2;
    for (final row in rows) {
      if (row is! List || row.length < 3) continue;
      final date = row[0].toString();
      final closeStr = row[2].toString();
      final close = double.tryParse(closeStr);
      if (close == null || !RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date)) {
        continue;
      }
      final d = decimalsOf(closeStr);
      if (d > dec) dec = d;
      byDate[date] = Bar(date, close);
    }
    if (byDate.isEmpty) throw DataException('行情数据为空或无法解析');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    return PriceSeries(
      security: s,
      bars: bars,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: label,
      decimals: dec > 4 ? 4 : dec,
    );
  }

  /// qt.gtimg.cn returns GBK text with "~"-separated fields:
  /// [3]=price [4]=prev close [30]=timestamp yyyyMMddHHmmss (A-share).
  @override
  Future<Quote> quote(Security s) async {
    final uri = Uri.parse('https://qt.gtimg.cn/q=${s.code}');
    final r = await httpGet(uri,
        headers: _headers, timeout: const Duration(seconds: 10));
    final body = latin1.decode(r.bodyBytes);
    final m = RegExp(r'="([^"]*)"').firstMatch(body);
    if (m == null || m.group(1)!.isEmpty) {
      throw DataException('腾讯没有该代码的实时报价');
    }
    final f = m.group(1)!.split('~');
    if (f.length < 5) throw DataException('腾讯实时报价格式无法识别');
    final price = double.tryParse(f[3]);
    if (price == null || price <= 0) {
      throw DataException('腾讯实时报价为空（可能未开盘或停牌）');
    }
    var asOf = '';
    if (f.length > 30) {
      final t = f[30];
      if (RegExp(r'^\d{14}$').hasMatch(t)) {
        asOf = '${t.substring(0, 4)}-${t.substring(4, 6)}-${t.substring(6, 8)} '
            '${t.substring(8, 10)}:${t.substring(10, 12)}:${t.substring(12, 14)}';
      } else if (t.contains('/') || t.contains('-')) {
        asOf = t.replaceAll('/', '-'); // HK "2026/11/13 16:08:11", US "2026-11-13 16:00:00"
      }
    }
    if (asOf.isEmpty) throw DataException('腾讯实时报价没有时间戳，无法判断新旧');
    return Quote(
      security: s,
      price: price,
      prevClose: double.tryParse(f[4]),
      asOf: asOf,
      fetchedAt: DateTime.now(),
      source: name,
      usEastern: s.isUs,
    );
  }
}
