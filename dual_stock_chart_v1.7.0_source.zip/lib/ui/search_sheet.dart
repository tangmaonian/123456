import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/market_data_source.dart';
import '../data/models.dart';
import '../data/watchlist_io.dart';

/// Bottom sheet with two tabs: 自选 (watchlist) and 搜索 (search / indices).
/// Tap a row to select it; tap the star to add/remove from the watchlist.
class SearchSheet extends StatefulWidget {
  const SearchSheet({
    super.key,
    required this.source,
    required this.title,
    required this.watch,
    required this.onToggleWatch,
    required this.onImportWatch,
    this.allowNone = false,
  });
  final MarketDataSource source;
  final String title;
  final List<Security> watch;
  final void Function(Security) onToggleWatch;

  /// Adds imported securities to the watchlist; returns how many were new.
  final int Function(List<Security>) onImportWatch;

  /// Show a "无叠加（空白）" row (for the overlay slot).
  final bool allowNone;

  @override
  State<SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<SearchSheet> {
  final _controller = TextEditingController();
  Timer? _debounce;
  late List<Security> _watch = List<Security>.of(widget.watch);
  late int _tab = _watch.isEmpty ? 1 : 0;
  List<Security> _results = [];
  bool _loading = false;
  String? _error;
  int _req = 0;
  bool _searched = false;
  List<Security> _recent = [];

  @override
  void initState() {
    super.initState();
    _loadRecent();
  }

  Future<void> _loadRecent() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('recent_search_stocks_v1') ?? const <String>[];
    final parsed = <Security>[];
    for (final line in raw) {
      final split = line.indexOf('|');
      if (split <= 0) continue;
      parsed.add(Security(code: line.substring(0, split), name: line.substring(split + 1)));
    }
    if (mounted) setState(() => _recent = parsed);
  }

  Future<void> _rememberRecent(Security s) async {
    final next = <Security>[s, ..._recent.where((x) => x.code != s.code)];
    if (next.length > 12) next.removeRange(12, next.length);
    if (mounted) setState(() => _recent = next);
    final p = await SharedPreferences.getInstance();
    await p.setStringList('recent_search_stocks_v1',
        next.map((x) => '${x.code}|${x.name}').toList());
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  bool _isWatched(Security s) => _watch.any((w) => w.code == s.code);

  void _toggle(Security s) {
    setState(() {
      final i = _watch.indexWhere((w) => w.code == s.code);
      if (i >= 0) {
        _watch.removeAt(i);
      } else {
        _watch.add(s);
      }
    });
    widget.onToggleWatch(s);
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    final text = q.trim();
    if (text.isEmpty) {
      setState(() {
        _results = [];
        _error = null;
        _loading = false;
        _searched = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () => _search(text));
  }

  Future<void> _search(String q) async {
    final id = ++_req;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await widget.source.search(q);
      if (!mounted || id != _req) return;
      setState(() {
        _results = r;
        _loading = false;
        _searched = true;
      });
    } catch (e) {
      if (!mounted || id != _req) return;
      setState(() {
        _results = [];
        _loading = false;
        _error = e.toString();
      });
    }
  }

  Widget _tile(Security s) {
    final watched = _isWatched(s);
    return ListTile(
      dense: true,
      title: Text(s.name),
      subtitle: Text('${s.shortCode}　${s.marketLabel}'),
      trailing: IconButton(
        tooltip: watched ? '移出自选' : '加入自选',
        icon: Icon(watched ? Icons.star : Icons.star_border,
            color: watched ? Colors.amber.shade700 : Colors.black45),
        onPressed: () => _toggle(s),
      ),
      onTap: () async { await _rememberRecent(s); if (mounted) Navigator.pop(context, s); },
    );
  }

  void _showExport() {
    final text = exportWatchlist(_watch);
    var copied = false;
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('导出自选股'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SelectableText(text, style: const TextStyle(fontSize: 13)),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: text));
                setD(() => copied = true);
              },
              child: Text(copied ? '已复制，可粘贴到备忘录/文件保存' : '复制全部'),
            ),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('关闭')),
          ],
        ),
      ),
    );
  }

  void _showImport() {
    final c = TextEditingController();
    String? msg;
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('导入自选股'),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: c,
                    minLines: 3,
                    maxLines: 6,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: '粘贴导出的文本，每行：代码,名称\n也可只写代码，如 600519、00700、AAPL',
                    ),
                  ),
                  if (msg != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(msg!, style: const TextStyle(fontSize: 12)),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                final d = await Clipboard.getData(Clipboard.kTextPlain);
                final t = d?.text;
                if (t != null) setD(() => c.text = t);
              },
              child: const Text('从剪贴板粘贴'),
            ),
            TextButton(
              onPressed: () {
                final r = parseWatchlist(c.text);
                final added = widget.onImportWatch(r.items);
                setState(() {
                  for (final s in r.items) {
                    if (!_isWatched(s)) _watch.add(s);
                  }
                });
                setD(() => msg =
                    '新增 $added 只，已存在 ${r.items.length - added} 只，无法识别 ${r.skipped} 行');
              },
              child: const Text('导入'),
            ),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('关闭')),
          ],
        ),
      ),
    );
  }

  Widget _watchTab(bool showButtons) {
    return Column(
      children: [
        if (showButtons)
          Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            TextButton.icon(
              onPressed: _watch.isEmpty ? null : _showExport,
              icon: const Icon(Icons.upload_file, size: 18),
              label: const Text('导出'),
            ),
            TextButton.icon(
              onPressed: _showImport,
              icon: const Icon(Icons.download, size: 18),
              label: const Text('导入'),
            ),
          ]),
        ),
        Expanded(
          child: _watch.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('自选股为空。切到“搜索”，点股票右侧的星标即可加入自选；也可以点上面的“导入”。',
                      style: TextStyle(color: Colors.black54)),
                )
              : ListView.builder(
                  itemCount: _watch.length,
                  itemBuilder: (context, i) => _tile(_watch[i]),
                ),
        ),
      ],
    );
  }

  Widget _searchTab() {
    final showPresets = _controller.text.trim().isEmpty;
    final list = showPresets ? (_recent.isNotEmpty ? _recent : kPresets) : _results;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            controller: _controller,
            onChanged: (v) {
              setState(() {});
              _onChanged(v);
            },
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: '输入代码或名称，如 600519、茅台、AAPL',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),
        ),
        if (_loading) const LinearProgressIndicator(minHeight: 2),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(_error!, style: const TextStyle(color: Colors.red)),
          ),
        if (showPresets)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                _recent.isNotEmpty ? '最近搜索' : '常用指数',
                style: const TextStyle(color: Colors.black54),
              ),
            ),
          ),
        if (!showPresets && _searched && _results.isEmpty && _error == null)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('没有找到匹配的股票或指数'),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, i) => _tile(list[i]),
          ),
        ),
      ],
    );
  }

  Widget _tabChips() => Row(mainAxisSize: MainAxisSize.min, children: [
        ChoiceChip(
          label: Text('自选(${_watch.length})'),
          selected: _tab == 0,
          visualDensity: VisualDensity.compact,
          onSelected: (_) => setState(() => _tab = 0),
        ),
        const SizedBox(width: 8),
        ChoiceChip(
          label: const Text('搜索'),
          selected: _tab == 1,
          visualDensity: VisualDensity.compact,
          onSelected: (_) => setState(() => _tab = 1),
        ),
      ]);

  List<Widget> _ioButtons() => [
        TextButton.icon(
          onPressed: _watch.isEmpty ? null : _showExport,
          icon: const Icon(Icons.upload_file, size: 18),
          label: const Text('导出'),
        ),
        TextButton.icon(
          onPressed: _showImport,
          icon: const Icon(Icons.download, size: 18),
          label: const Text('导入'),
        ),
      ];

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final landscape = media.orientation == Orientation.landscape;
    final avail = media.size.height - media.viewInsets.bottom;
    final height = math.min(media.size.height * (landscape ? 0.94 : 0.75), avail);

    // Landscape: everything above the list sits in ONE compact row so the
    // scrollable list gets as much height as possible.
    final Widget header = landscape
        ? Padding(
            padding: const EdgeInsets.fromLTRB(12, 2, 4, 0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                Text(widget.title,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(width: 12),
                if (widget.allowNone) ...[
                  ActionChip(
                    label: const Text('无叠加（空白）'),
                    visualDensity: VisualDensity.compact,
                    onPressed: () => Navigator.pop(context, kNoOverlay),
                  ),
                  const SizedBox(width: 8),
                ],
                _tabChips(),
                if (_tab == 0) ..._ioButtons(),
                IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close)),
              ]),
            ),
          )
        : Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
              child: Row(children: [
                Expanded(
                    child: Text(widget.title,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold))),
                IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close)),
              ]),
            ),
            if (widget.allowNone)
              ListTile(
                dense: true,
                leading: const Icon(Icons.layers_clear_outlined),
                title: const Text('无叠加（空白）'),
                subtitle: const Text('只显示黑线，不叠加红线'),
                onTap: () => Navigator.pop(context, kNoOverlay),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Row(children: [_tabChips()]),
            ),
          ]);

    return Padding(
      padding: EdgeInsets.only(bottom: media.viewInsets.bottom),
      child: SizedBox(
        height: height,
        child: Column(
          children: [
            header,
            Expanded(child: _tab == 0 ? _watchTab(!landscape) : _searchTab()),
          ],
        ),
      ),
    );
  }
}
