import 'auto_source.dart';
import 'market_data_source.dart';

/// One internal automatic router; no provider picker is shown in the UI.
List<MarketDataSource> buildSources() => [AutoMarketDataSource()];
