import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

import 'models.dart';

// v1.7.0: 针对中国移动漫游 / 跨境弱网与上游网关 502 优化：
// 1. 保持每次请求使用全新短连接，避免复用被中间网关半关闭的长连接。
// 2. 放宽单次连接/读取超时，并对 502/503/504、连接断开、单次超时做有限次退避重试，
//    避免漫游高延迟下偶发抖动直接判死。

const List<Map<String, String>> _profiles = [
  {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Connection': 'close',
  },
  {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'close',
  },
  {
    'User-Agent':
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
    'Accept': '*/*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'close',
  },
];

http.Client _newClient({Duration connectTimeout = const Duration(seconds: 15)}) {
  final hc = HttpClient()
    ..connectionTimeout = connectTimeout
    ..idleTimeout = Duration.zero;
  return IOClient(hc);
}

String _bodyHint(List<int> bytes) {
  if (bytes.isEmpty) return '';
  final s = utf8
      .decode(bytes, allowMalformed: true)
      .replaceAll(RegExp(r'<[^>]*>'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (s.isEmpty) return '';
  return ' 内容：${s.length > 60 ? '${s.substring(0, 60)}…' : s}';
}

Future<http.Response> httpGet(
  Uri uri, {
  Map<String, String>? headers,
  Duration timeout = const Duration(seconds: 20),
  int maxAttempts = 3,
}) {
  return _httpGetWithRetry(uri, headers, timeout, maxAttempts);
}

Future<http.Response> _httpGetWithRetry(
  Uri uri,
  Map<String, String>? headers,
  Duration timeout,
  int maxAttempts,
) async {
  final attempts = maxAttempts < 1 ? 1 : maxAttempts;
  DataException? last;
  for (var i = 0; i < attempts; i++) {
    final connectTimeout =
        timeout.inSeconds > 15 ? const Duration(seconds: 15) : timeout;
    final client = _newClient(connectTimeout: connectTimeout);
    try {
      final r = await client
          .get(uri, headers: {..._profiles[i % _profiles.length], ...?headers})
          .timeout(timeout);
      if (r.statusCode == 200) return r;
      final err = DataException(
          '服务器返回错误（HTTP ${r.statusCode}）${_bodyHint(r.bodyBytes)}');
      if ((r.statusCode == 502 ||
              r.statusCode == 503 ||
              r.statusCode == 504 ||
              r.statusCode == 429) &&
          i < attempts - 1) {
        last = err;
      } else {
        throw err;
      }
    } on TimeoutException {
      last = DataException('请求超时，漫游网络响应较慢');
    } on HandshakeException {
      last = DataException('安全连接失败（HTTPS）');
    } on SocketException {
      last = DataException('网络连接失败，请检查网络');
    } on http.ClientException catch (e) {
      last = DataException('网络请求失败：${e.message}');
    } on HttpException catch (e) {
      last = DataException('网络请求失败：${e.message}');
    } finally {
      client.close();
    }
    if (i < attempts - 1) {
      await Future<void>.delayed(Duration(milliseconds: 500 * (i + 1)));
    }
  }
  throw last ?? DataException('网络请求失败');
}

/// Minimal GBK decoder for the few characters we need (stock names).
String decodeAscii(Uint8List bytes) => latin1.decode(bytes);

int decimalsOf(String s) {
  final dot = s.indexOf('.');
  if (dot < 0) return 0;
  return s.length - dot - 1;
}
