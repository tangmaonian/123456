import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';
import 'eastmoney_source.dart';
import 'yahoo_source.dart';

/// Market-aware provider router. Provider selection is internal and never
/// exposed as a user setting.
/// Default order for CN/HK daily history: Eastmoney -> Tencent -> Yahoo (roaming fallback).
class AutoMarketDataSource implements MarketDataSource {
  final EastmoneyDataSource _em = EastmoneyDataSource();
  final TencentDataSource _tx = TencentDataSource();
  final YahooDataSource _yh = YahooDataSource();

  @override
  String get id => 'auto';
  @override
  String get name => '自动';
  @override
  bool get supportsQuote => true;

  bool _global(Security s) =>
      s.isUs ||
      s.isOther ||
      (s.isHk && !RegExp(r'^hk\d{5}$').hasMatch(s.code));

  List<MarketDataSource> _historyProviders(Security s) => _global(s)
      ? <MarketDataSource>[_yh]
      : <MarketDataSource>[_em, _tx, _yh];

  List<MarketDataSource> _quoteProviders(Security s) => _global(s)
      ? <MarketDataSource>[_yh]
      : <MarketDataSource>[_em, _tx];

  Future<T> _try<T>(
    List<MarketDataSource> providers,
    Future<T> Function(MarketDataSource) call,
    bool Function(T) valid, {
    Duration perProviderTimeout = const Duration(seconds: 24),
  }) async {
    final errors = <String>[];
    for (final p in providers) {
      try {
        final v = await call(p).timeout(perProviderTimeout);
        if (valid(v)) return v;
        errors.add('${p.name}返回空数据');
      } catch (e) {
        errors.add('${p.name}: $e');
      }
    }
    throw DataException(errors.join('；'));
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) => _try(
        _historyProviders(s),
        (p) => p.history(s, adjusted: adjusted),
        (v) =>
            v.bars.isNotEmpty &&
            v.bars.any((b) => b.close > 0 && b.close.isFinite),
        perProviderTimeout: const Duration(seconds: 25),
      );

  @override
  Future<Quote> quote(Security s) => _try(
        _quoteProviders(s),
        (p) => p.quote(s),
        (v) => v.price > 0 && v.price.isFinite,
        perProviderTimeout: const Duration(seconds: 15),
      );

  @override
  Future<List<Security>> search(String query) async {
    final results = await Future.wait([
      _tx.search(query).catchError((_) => <Security>[]),
      _yh.search(query).catchError((_) => <Security>[]),
    ]);
    final seen = <String>{};
    return [...results[0], ...results[1]]
        .where((s) => seen.add(s.code))
        .toList();
  }
}
