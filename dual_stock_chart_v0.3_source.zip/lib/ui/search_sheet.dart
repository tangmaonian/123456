import 'dart:async';

import 'package:flutter/material.dart';

import '../data/market_data_source.dart';
import '../data/models.dart';

/// Bottom sheet: search by code or name, or pick a preset index.
class SearchSheet extends StatefulWidget {
  const SearchSheet({super.key, required this.source, required this.title});
  final MarketDataSource source;
  final String title;

  @override
  State<SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<SearchSheet> {
  final _controller = TextEditingController();
  Timer? _debounce;
  List<Security> _results = [];
  bool _loading = false;
  String? _error;
  int _req = 0;
  bool _searched = false;

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    final text = q.trim();
    if (text.isEmpty) {
      setState(() {
        _results = [];
        _error = null;
        _loading = false;
        _searched = false;
      });
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 400), () => _search(text));
  }

  Future<void> _search(String q) async {
    final id = ++_req;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await widget.source.search(q);
      if (!mounted || id != _req) return;
      setState(() {
        _results = r;
        _loading = false;
        _searched = true;
      });
    } catch (e) {
      if (!mounted || id != _req) return;
      setState(() {
        _results = [];
        _loading = false;
        _error = e.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final showPresets = _controller.text.trim().isEmpty;
    final list = showPresets ? kPresets : _results;
    return Padding(
      padding: EdgeInsets.only(bottom: media.viewInsets.bottom),
      child: SizedBox(
        height: media.size.height * 0.7,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
              child: Row(children: [
                Expanded(
                    child: Text(widget.title,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold))),
                IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close)),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _controller,
                autofocus: true,
                onChanged: (v) {
                  setState(() {});
                  _onChanged(v);
                },
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: '输入代码或名称，如 600519、茅台、AAPL',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
            ),
            if (_loading) const LinearProgressIndicator(minHeight: 2),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!, style: const TextStyle(color: Colors.red)),
              ),
            if (showPresets)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 10, 16, 2),
                child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('常用指数', style: TextStyle(color: Colors.black54))),
              ),
            if (!showPresets && _searched && _results.isEmpty && _error == null)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('没有找到匹配的股票或指数'),
              ),
            Expanded(
              child: ListView.builder(
                itemCount: list.length,
                itemBuilder: (context, i) {
                  final s = list[i];
                  return ListTile(
                    dense: true,
                    title: Text(s.name),
                    subtitle: Text('${s.shortCode}　${s.marketLabel}'),
                    onTap: () => Navigator.pop(context, s),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
