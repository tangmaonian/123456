import 'dart:async';

import 'package:flutter/material.dart';

import '../chart/chart_data.dart';
import '../chart/chart_painter.dart';
import '../data/market_data_source.dart';
import '../data/models.dart';
import '../data/sources.dart';
import 'search_sheet.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});
  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final List<MarketDataSource> _sources = buildSources();
  late MarketDataSource _src = _sources.first;
  Timer? _quoteTimer;

  // The two selections are fully independent.
  Security _mainSec = const Security(code: 'sh600519', name: '贵州茅台');
  Security _overSec = const Security(code: 'sh000001', name: '上证指数');
  PriceSeries? _mainSeries;
  PriceSeries? _overSeries;
  String? _mainErr;
  String? _overErr;
  Quote? _mainQuote;
  Quote? _overQuote;
  String? _mainQErr;
  String? _overQErr;
  bool _mainLoading = false;
  bool _overLoading = false;

  ChartData _data = ChartData.empty();
  bool _adjusted = false;
  bool _normalized = false;
  bool _cursorMode = true; // one finger: move cursor (true) or pan (false)

  double _left = 0;
  double _span = 120;
  String? _cursorDate;

  // gesture state
  int _pc = 0;
  double _span0 = 120;
  double _scale0 = 1;
  double _anchorU = 0;
  double _anchorFrac = 0.5;

  @override
  void initState() {
    super.initState();
    _loadAll();
    // Refresh snapshot prices only (not history) every 30 s.
    _quoteTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _loadQuote(true);
      _loadQuote(false);
    });
  }

  @override
  void dispose() {
    _quoteTimer?.cancel();
    super.dispose();
  }

  void _loadAll() {
    _load(true);
    _load(false);
    _loadQuote(true);
    _loadQuote(false);
  }

  Future<void> _loadQuote(bool isMain) async {
    final sec = isMain ? _mainSec : _overSec;
    final src = _src;
    try {
      final q = await src.quote(sec);
      if (!mounted) return;
      if ((isMain ? _mainSec : _overSec).code != sec.code || _src.id != src.id) {
        return;
      }
      setState(() {
        if (isMain) {
          _mainQuote = q;
          _mainQErr = null;
        } else {
          _overQuote = q;
          _overQErr = null;
        }
      });
    } catch (e) {
      if (!mounted) return;
      if ((isMain ? _mainSec : _overSec).code != sec.code || _src.id != src.id) {
        return;
      }
      setState(() {
        if (isMain) {
          _mainQuote = null;
          _mainQErr = e.toString();
        } else {
          _overQuote = null;
          _overQErr = e.toString();
        }
      });
    }
  }

  double _cl(double v, double a, double b) => v < a ? a : (v > b ? b : v);

  Future<void> _load(bool isMain) async {
    final sec = isMain ? _mainSec : _overSec;
    final adj = _adjusted;
    final src = _src;
    setState(() {
      if (isMain) {
        _mainLoading = true;
        _mainErr = null;
      } else {
        _overLoading = true;
        _overErr = null;
      }
    });
    try {
      final s = await src.history(sec, adjusted: adj);
      if (!mounted) return;
      final current = isMain ? _mainSec : _overSec;
      if (current.code != sec.code || _adjusted != adj || _src.id != src.id) {
        return; // stale
      }
      setState(() {
        if (isMain) {
          _mainSeries = s;
          _mainLoading = false;
        } else {
          _overSeries = s;
          _overLoading = false;
        }
        _rebuild();
      });
    } catch (e) {
      if (!mounted) return;
      final current = isMain ? _mainSec : _overSec;
      if (current.code != sec.code || _src.id != src.id) return;
      setState(() {
        if (isMain) {
          _mainSeries = null;
          _mainErr = e.toString();
          _mainLoading = false;
        } else {
          _overSeries = null;
          _overErr = e.toString();
          _overLoading = false;
        }
        _rebuild();
      });
    }
  }

  /// Re-align data after either series changed. Keeps view span and cursor
  /// date where possible and jumps to the latest bars.
  void _rebuild() {
    _data = ChartData.align(_mainSeries, _overSeries);
    final n = _data.length;
    if (n == 0) return;
    _span = _cl(_span, n < 10 ? n.toDouble() : 10.0, n.toDouble());
    _left = n - _span;
    if (_data.indexOf(_cursorDate) < 0) _cursorDate = null;
  }

  Future<void> _pick(bool isMain) async {
    final s = await showModalBottomSheet<Security>(
      context: context,
      isScrollControlled: true,
      builder: (_) => SearchSheet(
          source: _src, title: isMain ? '选择主股票（黑线）' : '选择叠加股票/指数（红线）'),
    );
    if (s == null || !mounted) return;
    setState(() {
      if (isMain) {
        _mainSec = s;
        _mainSeries = null;
        _mainQuote = null;
        _mainQErr = null;
      } else {
        _overSec = s;
        _overSeries = null;
        _overQuote = null;
        _overQErr = null;
      }
      _rebuild();
    });
    _load(isMain); // the other series is untouched
    _loadQuote(isMain);
  }

  // ---- gestures -------------------------------------------------------------

  int _idxAt(double dx, double plotW) {
    final n = _data.length;
    final u = _left + (dx - ChartPainter.leftMargin) / plotW * _span;
    return u.floor().clamp(0, n - 1).toInt();
  }

  void _setCursorAt(double dx, double plotW) {
    if (_data.length == 0) return;
    setState(() => _cursorDate = _data.dates[_idxAt(dx, plotW)]);
  }

  void _reinit(double focalDx, int pc, double scale, double plotW) {
    _pc = pc;
    _span0 = _span;
    _scale0 = scale <= 0 ? 1 : scale;
    final ci = _data.indexOf(_cursorDate);
    var frac = _cl((focalDx - ChartPainter.leftMargin) / plotW, 0, 1);
    if (ci >= 0) {
      final f = (ci + 0.5 - _left) / _span;
      if (f >= 0 && f <= 1) frac = f; // zoom around the selected date
    }
    _anchorFrac = frac;
    _anchorU = _left + frac * _span;
  }

  void _onScaleStart(ScaleStartDetails d, double plotW) {
    _reinit(d.localFocalPoint.dx, d.pointerCount, 1, plotW);
    if (d.pointerCount == 1 && _cursorMode) {
      _setCursorAt(d.localFocalPoint.dx, plotW);
    }
  }

  void _onScaleUpdate(ScaleUpdateDetails d, double plotW) {
    final n = _data.length;
    if (n == 0) return;
    if (d.pointerCount != _pc) {
      _reinit(d.localFocalPoint.dx, d.pointerCount, d.scale, plotW);
    }
    if (d.pointerCount >= 2) {
      final ratio = d.scale / _scale0;
      final minSpan = n < 10 ? n.toDouble() : 10.0;
      final ns = _cl(_span0 / ratio, minSpan, n.toDouble());
      final nl = _cl(_anchorU - _anchorFrac * ns, 0, n - ns);
      setState(() {
        _span = ns;
        _left = nl;
      });
    } else if (_cursorMode) {
      _setCursorAt(d.localFocalPoint.dx, plotW);
    } else {
      final nl = _left - d.focalPointDelta.dx / plotW * _span;
      setState(() => _left = _cl(nl, 0, n - _span));
    }
  }

  void _switchSource(MarketDataSource src) {
    if (src.id == _src.id) return;
    setState(() {
      _src = src;
      _mainSeries = null;
      _overSeries = null;
      _mainQuote = null;
      _overQuote = null;
      _mainErr = null;
      _overErr = null;
      _mainQErr = null;
      _overQErr = null;
      _rebuild();
    });
    _loadAll();
  }

  void _jumpLatest() => setState(() => _left = _data.length - _span);

  // ---- status text ------------------------------------------------------------

  String _two(int v) => v.toString().padLeft(2, '0');

  String _statusFor(String tag, Security sec, PriceSeries? s, String? err,
      bool loading) {
    if (loading) return '$tag ${sec.name}：加载中…';
    if (err != null) return '$tag ${sec.name}：获取失败 - $err';
    if (s == null) return '$tag ${sec.name}：无数据';
    final t = s.fetchedAt;
    return '$tag ${sec.name}：${s.source}日线·${s.adjustment}｜最新K线 ${s.lastDate}｜'
        '获取于 ${_two(t.hour)}:${_two(t.minute)}:${_two(t.second)}';
  }

  String _quoteText(String tag, Security sec, Quote? q, String? err, int dec) {
    if (err != null) return '$tag ${sec.name} 最新价：获取失败 - $err';
    if (q == null) return '$tag ${sec.name} 最新价：加载中…';
    final age = q.ageMinutes();
    String ageText;
    if (age == null) {
      ageText = '报价时间 ${q.asOf}（无法判断延迟）';
    } else if (age < 0) {
      ageText = '报价时间 ${q.asOf}';
    } else if (age <= 30) {
      ageText = '报价时间 ${q.asOf}｜延迟约 $age 分钟';
    } else if (age < 60 * 48) {
      final h = age ~/ 60;
      ageText = '报价时间 ${q.asOf}｜已过 ${h >= 1 ? '$h 小时' : '$age 分钟'}（非盘中，为最后成交价）';
    } else {
      ageText = '报价时间 ${q.asOf}｜数据已过期';
    }
    return '$tag ${sec.name} 最新价 ${q.price.toStringAsFixed(dec)}｜${q.source}｜$ageText';
  }

  Widget _selector(bool isMain) {
    final sec = isMain ? _mainSec : _overSec;
    final color = isMain ? Colors.black : const Color(0xFFE53935);
    final loading = isMain ? _mainLoading : _overLoading;
    return Expanded(
      child: InkWell(
        onTap: () => _pick(isMain),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
          decoration: BoxDecoration(
            border: Border.all(color: color, width: 1.4),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(children: [
            Container(width: 10, height: 10, color: color),
            const SizedBox(width: 6),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(sec.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13, fontWeight: FontWeight.bold)),
                  Text('${sec.shortCode} ${sec.marketLabel}',
                      style: const TextStyle(fontSize: 10, color: Colors.black54)),
                ],
              ),
            ),
            if (loading)
              const SizedBox(
                  width: 12,
                  height: 12,
                  child: CircularProgressIndicator(strokeWidth: 2))
            else
              const Icon(Icons.search, size: 16),
          ]),
        ),
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(right: 6),
        child: ChoiceChip(
          label: Text(label, style: const TextStyle(fontSize: 12)),
          selected: selected,
          visualDensity: VisualDensity.compact,
          onSelected: (_) => onTap(),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cursorIdx = _data.indexOf(_cursorDate);
    final mainStatus =
        _statusFor('黑', _mainSec, _mainSeries, _mainErr, _mainLoading);
    final overStatus =
        _statusFor('红', _overSec, _overSeries, _overErr, _overLoading);
    final mainQ = _quoteText('黑', _mainSec, _mainQuote, _mainQErr,
        _mainSeries?.decimals ?? 2);
    final overQ = _quoteText('红', _overSec, _overQuote, _overQErr,
        _overSeries?.decimals ?? 2);
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 6, 8, 4),
              child: Row(children: [
                _selector(true),
                const SizedBox(width: 8),
                _selector(false),
              ]),
            ),
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                children: [
                  for (final src in _sources)
                    _chip(src.name, src.id == _src.id, () => _switchSource(src)),
                  _chip('实际价格', !_normalized,
                      () => setState(() => _normalized = false)),
                  _chip('归一化', _normalized,
                      () => setState(() => _normalized = true)),
                  _chip('光标', _cursorMode, () => setState(() => _cursorMode = true)),
                  _chip('平移', !_cursorMode,
                      () => setState(() => _cursorMode = false)),
                  _chip('不复权', !_adjusted, () {
                    if (_adjusted) {
                      setState(() => _adjusted = false);
                      _load(true);
                      _load(false);
                    }
                  }),
                  _chip('前复权', _adjusted, () {
                    if (!_adjusted) {
                      setState(() => _adjusted = true);
                      _load(true);
                      _load(false);
                    }
                  }),
                  IconButton(
                    tooltip: '回到最新',
                    visualDensity: VisualDensity.compact,
                    onPressed: _jumpLatest,
                    icon: const Icon(Icons.last_page),
                  ),
                  IconButton(
                    tooltip: '刷新行情',
                    visualDensity: VisualDensity.compact,
                    onPressed: _loadAll,
                    icon: const Icon(Icons.refresh),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(builder: (context, cons) {
                final size = Size(cons.maxWidth, cons.maxHeight);
                final plotW =
                    size.width - ChartPainter.leftMargin - ChartPainter.rightMargin;
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTapUp: (d) => _setCursorAt(d.localPosition.dx, plotW),
                  onScaleStart: (d) => _onScaleStart(d, plotW),
                  onScaleUpdate: (d) => _onScaleUpdate(d, plotW),
                  child: RepaintBoundary(
                    child: CustomPaint(
                      size: size,
                      painter: ChartPainter(
                        data: _data,
                        left: _left,
                        span: _span,
                        cursor: cursorIdx,
                        normalized: _normalized,
                        mainName: _mainSec.name,
                        overName: _overSec.name,
                        mainDec: _mainSeries?.decimals ?? 2,
                        overDec: _overSeries?.decimals ?? 2,
                      ),
                    ),
                  ),
                );
              }),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 2, 8, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(mainStatus,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 9.5,
                          color: _mainErr != null ? Colors.red : Colors.black54)),
                  Text(overStatus,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 9.5,
                          color: _overErr != null ? Colors.red : Colors.black54)),
                  Text(mainQ,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 9.5,
                          color: _mainQErr != null ? Colors.red : Colors.black87)),
                  Text(overQ,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 9.5,
                          color: _overQErr != null ? Colors.red : Colors.black87)),
                  const Text('图中曲线为日线收盘价；“最新价”是另行获取的报价，以报价时间为准，来自免费公开接口，不保证实时。',
                      style: TextStyle(fontSize: 9.5, color: Colors.black45)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
