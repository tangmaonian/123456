import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'chart_data.dart';

/// Draws both curves, axes, crosshair and readout.
///
/// Bar i occupies x-units [i, i+1]; the visible window is [left, left+span].
class ChartPainter extends CustomPainter {
  ChartPainter({
    required this.data,
    required this.left,
    required this.span,
    required this.cursor,
    required this.normalized,
    required this.mainName,
    required this.overName,
    required this.mainDec,
    required this.overDec,
  });

  static const double leftMargin = 54;
  static const double rightMargin = 60;
  static const Color mainColor = Colors.black;
  static const Color overColor = Color(0xFFE53935);

  final ChartData data;
  final double left;
  final double span;
  final int cursor; // -1 when no cursor
  final bool normalized;
  final String mainName;
  final String overName;
  final int mainDec;
  final int overDec;

  TextPainter _tp(String t,
      {Color color = Colors.black87, double size = 11, FontWeight? weight}) {
    return TextPainter(
      text: TextSpan(
          text: t,
          style: TextStyle(color: color, fontSize: size, fontWeight: weight)),
      textDirection: TextDirection.ltr,
    )..layout();
  }

  List<double> _expand(double mn, double mx) {
    if (mx - mn < 1e-9) {
      final p = mx.abs() * 0.01 + 0.01;
      return [mn - p, mx + p];
    }
    final p = (mx - mn) * 0.08;
    return [mn - p, mx + p];
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    final plot = Rect.fromLTRB(
        leftMargin, 8, size.width - rightMargin, size.height - 22);
    final n = data.length;
    if (n == 0) {
      final t = _tp('暂无行情数据', color: Colors.black45, size: 14);
      t.paint(canvas, Offset((size.width - t.width) / 2, size.height / 2));
      return;
    }
    final lo = left.floor().clamp(0, n - 1).toInt();
    final hi = (left + span).ceil().clamp(0, n - 1).toInt();
    double xOf(num i) => plot.left + (i + 0.5 - left) / span * plot.width;

    // ---- value transforms -------------------------------------------------
    var base = -1;
    var mb = 1.0, ob = 1.0;
    if (normalized) {
      base = data.commonBase(lo, hi, cursor);
      if (base >= 0) {
        mb = data.main[base]!;
        ob = data.over[base]!;
      }
    }
    double? mv(int i) {
      final v = data.main[i];
      if (v == null) return null;
      if (!normalized) return v;
      return base < 0 ? null : v / mb * 100;
    }

    double? ov(int i) {
      final v = data.over[i];
      if (v == null) return null;
      if (!normalized) return v;
      return base < 0 ? null : v / ob * 100;
    }

    List<double>? rangeOf(List<double? Function(int)> fns) {
      double? mn, mx;
      for (final f in fns) {
        for (var i = lo; i <= hi; i++) {
          final v = f(i);
          if (v == null) continue;
          mn = mn == null ? v : math.min(mn, v);
          mx = mx == null ? v : math.max(mx, v);
        }
      }
      if (mn == null || mx == null) return null;
      return _expand(mn, mx);
    }

    List<double>? rRange; // right axis (main, or shared in normalized mode)
    List<double>? lRange; // left axis (overlay actual price)
    if (normalized) {
      rRange = rangeOf([mv, ov]);
    } else {
      rRange = rangeOf([mv]);
      lRange = rangeOf([ov]);
    }

    double yOf(double v, List<double> r) =>
        plot.bottom - (v - r[0]) / (r[1] - r[0]) * plot.height;

    // ---- grid + axes ------------------------------------------------------
    final gridPaint = Paint()
      ..color = const Color(0xFFE3E7EA)
      ..strokeWidth = 0.7;
    final axisPaint = Paint()
      ..color = const Color(0xFF9AA5AD)
      ..strokeWidth = 1;
    canvas.drawRect(plot, Paint()
      ..color = const Color(0xFFB8C0C6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8);

    void drawAxis(List<double> r, bool rightSide, Color color) {
      final ticks = niceTicks(r[0], r[1]);
      final step = ticks.length > 1 ? ticks[1] - ticks[0] : 1.0;
      final d = decimalsForStep(step);
      for (final t in ticks) {
        final y = yOf(t, r);
        if (rightSide || rRange == null) {
          canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
        }
        final tp = _tp(t.toStringAsFixed(d), color: color, size: 10);
        final x = rightSide ? plot.right + 4 : plot.left - 4 - tp.width;
        tp.paint(canvas, Offset(x, y - tp.height / 2));
      }
    }

    if (rRange != null) drawAxis(rRange, true, Colors.black87);
    if (lRange != null) drawAxis(lRange, false, overColor);
    canvas.drawLine(Offset(plot.right, plot.top), Offset(plot.right, plot.bottom), axisPaint);

    // x-axis labels
    final showMonthOnly = span > 150;
    for (var k = 0; k <= 3; k++) {
      final u = left + span * k / 3;
      final i = (u - 0.5).round().clamp(0, n - 1).toInt();
      final ds = data.dates[i];
      final label = showMonthOnly ? ds.substring(0, 7) : ds.substring(5);
      final tp = _tp(label, color: Colors.black54, size: 10);
      var x = plot.left + plot.width * k / 3 - tp.width / 2;
      x = x.clamp(0.0, size.width - tp.width).toDouble();
      tp.paint(canvas, Offset(x, plot.bottom + 4));
    }

    // ---- curves -----------------------------------------------------------
    canvas.save();
    canvas.clipRect(plot);
    void drawLine(double? Function(int) f, List<double>? r, Color c, double w) {
      if (r == null) return;
      final path = Path();
      var started = false;
      for (var i = math.max(0, lo - 3); i <= math.min(n - 1, hi + 3); i++) {
        final v = f(i);
        if (v == null) continue; // bridge dates with no data
        final o = Offset(xOf(i), yOf(v, r));
        if (!started) {
          path.moveTo(o.dx, o.dy);
          started = true;
        } else {
          path.lineTo(o.dx, o.dy);
        }
      }
      canvas.drawPath(
          path,
          Paint()
            ..color = c
            ..style = PaintingStyle.stroke
            ..strokeWidth = w
            ..strokeJoin = StrokeJoin.round);
    }

    drawLine(ov, normalized ? rRange : lRange, overColor, 1.6);
    drawLine(mv, rRange, mainColor, 1.8);
    canvas.restore();

    // caption
    String caption;
    if (normalized) {
      caption = base >= 0
          ? '归一化（基准日 ${data.dates[base]} = 100）· 非实际股价'
          : '可见区间内两只股票没有共同交易日，无法归一化';
    } else {
      caption = '右轴：黑线实际价格　左轴：红线实际价格';
    }
    _tp(caption, color: Colors.black45, size: 10).paint(canvas, Offset(plot.left + 4, plot.top + 2));

    // ---- crosshair --------------------------------------------------------
    if (cursor >= 0 && cursor < n) {
      final cx = xOf(cursor);
      final visible = cx >= plot.left && cx <= plot.right;
      final mVal = data.main[cursor];
      final oVal = data.over[cursor];
      final mPlot = mv(cursor);
      final oPlot = ov(cursor);

      if (visible) {
        final cp = Paint()
          ..color = const Color(0xFF455A64)
          ..strokeWidth = 0.9;
        canvas.drawLine(Offset(cx, plot.top), Offset(cx, plot.bottom), cp);

        double? hy;
        if (mPlot != null && rRange != null) {
          hy = yOf(mPlot, rRange);
        } else if (oPlot != null) {
          final r = normalized ? rRange : lRange;
          if (r != null) hy = yOf(oPlot, r);
        }
        if (hy != null && hy >= plot.top && hy <= plot.bottom) {
          canvas.drawLine(Offset(plot.left, hy), Offset(plot.right, hy), cp);
        }
        if (mPlot != null && rRange != null) {
          final y = yOf(mPlot, rRange);
          canvas.drawCircle(Offset(cx, y), 3.5, Paint()..color = mainColor);
          _tag(canvas, plot, true, y,
              normalized ? mPlot.toStringAsFixed(2) : mPlot.toStringAsFixed(mainDec), mainColor);
        }
        if (oPlot != null) {
          final r = normalized ? rRange : lRange;
          if (r != null) {
            final y = yOf(oPlot, r);
            canvas.drawCircle(Offset(cx, y), 3.5, Paint()..color = overColor);
            if (!normalized) {
              _tag(canvas, plot, false, y, oPlot.toStringAsFixed(overDec), overColor);
            }
          }
        }
      }

      // readout box
      String line(String name, double? actual, double? norm, int dec) {
        if (actual == null) return '$name  无数据';
        final s = '$name  ${actual.toStringAsFixed(dec)}';
        return normalized && norm != null ? '$s（归一化 ${norm.toStringAsFixed(2)}）' : s;
      }

      final tpDate = _tp(data.dates[cursor], weight: FontWeight.bold);
      final tpMain = _tp('● ${line(mainName, mVal, mPlot, mainDec)}', color: mainColor);
      final tpOver = _tp('● ${line(overName, oVal, oPlot, overDec)}', color: overColor);
      final w = math.max(tpDate.width, math.max(tpMain.width, tpOver.width)) + 14;
      final h = tpDate.height + tpMain.height + tpOver.height + 12;
      final onLeftHalf = (cx - plot.left) < plot.width / 2;
      final bx = onLeftHalf ? plot.right - w - 4 : plot.left + 4;
      final box = RRect.fromRectAndRadius(
          Rect.fromLTWH(bx, plot.top + 18, w, h), const Radius.circular(6));
      canvas.drawRRect(box, Paint()..color = const Color(0xE6FFFFFF));
      canvas.drawRRect(
          box,
          Paint()
            ..color = const Color(0xFF90A4AE)
            ..style = PaintingStyle.stroke);
      var ty = plot.top + 18 + 5;
      tpDate.paint(canvas, Offset(bx + 7, ty));
      ty += tpDate.height + 1;
      tpMain.paint(canvas, Offset(bx + 7, ty));
      ty += tpMain.height + 1;
      tpOver.paint(canvas, Offset(bx + 7, ty));
    }
  }

  void _tag(Canvas canvas, Rect plot, bool rightSide, double y, String text, Color bg) {
    final tp = _tp(text, color: Colors.white, size: 10, weight: FontWeight.bold);
    final w = tp.width + 6;
    final x = rightSide ? plot.right + 1 : plot.left - 1 - w;
    final r = Rect.fromLTWH(x, y - tp.height / 2 - 1, w, tp.height + 2);
    canvas.drawRect(r, Paint()..color = bg);
    tp.paint(canvas, Offset(x + 3, y - tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant ChartPainter old) => true;
}
