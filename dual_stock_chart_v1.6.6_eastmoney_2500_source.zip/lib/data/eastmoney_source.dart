import 'dart:convert';

import 'package:http/http.dart' as http;

import 'http_util.dart';
import 'market_data_source.dart';
import 'models.dart';
import 'tencent_source.dart';

/// Eastmoney: daily K-line (push2his / push2 / push2delay) and snapshot quote (push2 / push2delay).
/// A-shares, A-share indices, and 5-digit HK stocks. Search reuses Tencent's search box.
class EastmoneyDataSource implements MarketDataSource {
  static const int _targetBars = 2500;
  static const List<int> _fallbackLimits = [2500, 1200, 600];
  static const List<String> _klineHosts = [
    'push2his.eastmoney.com',
    'push2.eastmoney.com',
    'push2delay.eastmoney.com',
  ];
  static const List<String> _quoteHosts = [
    'push2.eastmoney.com',
    'push2delay.eastmoney.com',
  ];
  static const Map<String, String> _headers = {
    'Referer': 'https://quote.eastmoney.com/',
    'Origin': 'https://quote.eastmoney.com',
  };
  final TencentDataSource _searcher = TencentDataSource();

  @override
  String get id => 'eastmoney';
  @override
  String get name => '东方财富';
  @override
  bool get supportsQuote => true;

  @override
  Future<List<Security>> search(String query) async {
    final all = await _searcher.search(query);
    return all.where((s) => s.isCn || s.isHk).toList();
  }

  /// secid = market.code ; 1 = Shanghai, 0 = Shenzhen/Beijing, 116 = HK.
  String _secid(Security s) {
    if (s.isHk) {
      if (RegExp(r'^hk\d{5}$').hasMatch(s.code)) return '116.${s.shortCode}';
      throw DataException('东方财富源暂不支持该港股指数，请换数据源');
    }
    if (!s.isCn) throw DataException('东方财富源仅支持A股和港股个股，请切换数据源查看美股');
    final market = s.code.startsWith('sh') ? '1' : '0';
    return '$market.${s.shortCode}';
  }

  Future<PriceSeries> _fetchKline(Security s,
      {required bool adjusted, required int limit}) async {
    final params = <String, String>{
      'secid': _secid(s),
      'fields1': 'f1,f2,f3,f4,f5,f6',
      'fields2': 'f51,f52,f53,f54,f55,f56,f57',
      'klt': '101',
      'fqt': adjusted ? '1' : '0',
      'beg': '0',
      'end': '20500101',
      'lmt': '$limit',
      'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
    };
    http.Response? r;
    Object? lastErr;
    for (final host in _klineHosts) {
      try {
        r = await httpGet(
          Uri.https(host, '/api/qt/stock/kline/get', params),
          headers: _headers,
          timeout: const Duration(seconds: 12),
        );
        break;
      } catch (e) {
        lastErr = e;
      }
    }
    if (r == null) {
      throw lastErr is DataException ? lastErr : DataException('$lastErr');
    }
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
    } on FormatException {
      throw DataException('东方财富数据格式无法识别');
    }
    if (j is Map && j['rc'] is num && (j['rc'] as num) != 0 && j['data'] == null) {
      throw DataException('东方财富接口返回异常（rc=${j['rc']}）');
    }
    final data = (j is Map) ? j['data'] : null;
    final lines = (data is Map) ? data['klines'] : null;
    if (lines is! List || lines.isEmpty) {
      throw DataException('东方财富没有该代码的日线行情（${s.code}）');
    }
    // each line: "date,open,close,high,low,volume,amount"
    final byDate = <String, Bar>{};
    var dec = 2;
    for (final line in lines) {
      final p = line.toString().split(',');
      if (p.length < 3) continue;
      final dateRaw = p[0].trim();
      if (dateRaw.length < 10) continue;
      final date = dateRaw.substring(0, 10);
      if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(date)) continue;
      final closeStr = p[2].trim();
      final c = double.tryParse(closeStr);
      if (c == null || !c.isFinite || c <= 0) continue;
      final d = decimalsOf(closeStr);
      if (d > dec) dec = d;
      byDate[date] = Bar(date, c);
    }
    if (byDate.isEmpty) throw DataException('东方财富日线数据为空或无法解析');
    final bars = byDate.values.toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    final trimmed =
        bars.length > _targetBars ? bars.sublist(bars.length - _targetBars) : bars;
    return PriceSeries(
      security: s,
      bars: trimmed,
      fetchedAt: DateTime.now(),
      source: name,
      adjustment: adjusted ? '前复权' : '不复权',
      decimals: dec > 4 ? 4 : dec,
    );
  }

  @override
  Future<PriceSeries> history(Security s, {required bool adjusted}) async {
    Object? lastErr;
    for (var i = 0; i < _fallbackLimits.length; i++) {
      final lmt = _fallbackLimits[i];
      try {
        return await _fetchKline(s, adjusted: adjusted, limit: lmt);
      } on DataException catch (e) {
        lastErr = e;
        // 代码本身无行情或不支持该市场时直接抛出，避免无意义重试
        if (e.message.contains('暂不支持') ||
            e.message.contains('仅支持') ||
            e.message.contains('没有该代码的日线行情')) {
          rethrow;
        }
      } catch (e) {
        lastErr = DataException('$e');
      }
    }
    throw lastErr is DataException ? lastErr : DataException('${lastErr ?? '东方财富日线请求失败'}');
  }

  /// push2 stock/get: f43=latest price, f60=prev close, f86=quote unix time.
  /// With fltt=2 prices come back as plain decimals.
  @override
  Future<Quote> quote(Security s) async {
    final secid = _secid(s);
    http.Response? r;
    Object? lastErr;
    for (final host in _quoteHosts) {
      try {
        final uri = Uri.https(host, '/api/qt/stock/get', {
          'secid': secid,
          'fields': 'f43,f60,f86',
          'fltt': '2',
          'invt': '2',
          'ut': 'fa5fd1943c7b386f172d6893dbfba10b',
        });
        r = await httpGet(uri,
            headers: _headers, timeout: const Duration(seconds: 9));
        break;
      } catch (e) {
        lastErr = e;
      }
    }
    if (r == null) {
      throw lastErr is DataException ? lastErr : DataException('$lastErr');
    }
    dynamic j;
    try {
      j = jsonDecode(utf8.decode(r.bodyBytes, allowMalformed: true));
    } on FormatException {
      throw DataException('东方财富实时报价格式无法识别');
    }
    final d = (j is Map) ? j['data'] : null;
    if (d is! Map) throw DataException('东方财富没有该代码的实时报价');
    final price = (d['f43'] is num) ? (d['f43'] as num).toDouble() : null;
    if (price == null || price <= 0) {
      throw DataException('东方财富实时报价为空（可能未开盘或停牌）');
    }
    final ts = d['f86'];
    if (ts is! num || ts <= 0) {
      throw DataException('东方财富实时报价没有时间戳，无法判断新旧');
    }
    final t = DateTime.fromMillisecondsSinceEpoch(ts.toInt() * 1000, isUtc: true)
        .add(const Duration(hours: 8));
    String two(int v) => v.toString().padLeft(2, '0');
    final asOf = '${t.year}-${two(t.month)}-${two(t.day)} '
        '${two(t.hour)}:${two(t.minute)}:${two(t.second)}';
    return Quote(
      security: s,
      price: price,
      prevClose: (d['f60'] is num) ? (d['f60'] as num).toDouble() : null,
      asOf: asOf,
      fetchedAt: DateTime.now(),
      source: name,
    );
  }
}
