import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';

import 'models.dart';

// v1.6.4: 不再复用长连接。
// v1.6.0~1.6.3 使用了一个全局长连接 http.Client。腾讯/东方财富网关会在空闲后
// 单方面断开长连接，Dart 复用已被服务器关闭的连接时就会报
// "Connection closed before full header was received"。
// 现在每次请求使用全新连接（用完即关），连接层失败时换一套请求头重试一次，
// 只对“连接被断开”这类连接层错误重试一次；超时和 HTTP 错误码不重试。

const List<Map<String, String>> _profiles = [
  {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 13) DualStockChart/0.3',
    'Accept': '*/*',
    'Connection': 'close',
  },
  {
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
    'Accept': '*/*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Connection': 'close',
  },
  {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'close',
  },
];

const int _maxAttempts = 2;

http.Client _newClient() {
  final hc = HttpClient()
    ..connectionTimeout = const Duration(seconds: 10)
    ..idleTimeout = Duration.zero;
  return IOClient(hc);
}

Future<http.Response> httpGet(Uri uri,
    {Map<String, String>? headers,
    Duration timeout = const Duration(seconds: 15)}) {
  return _httpGetWithRetry(uri, headers, timeout);
}

Future<http.Response> _httpGetWithRetry(
    Uri uri, Map<String, String>? headers, Duration timeout) async {
  DataException? last;
  for (var i = 0; i < _maxAttempts; i++) {
    final client = _newClient();
    try {
      final r = await client
          .get(uri, headers: {..._profiles[i % _profiles.length], ...?headers})
          .timeout(timeout);
      if (r.statusCode == 200) return r;
      throw DataException('服务器返回错误（HTTP ${r.statusCode}）');
    } on TimeoutException {
      throw DataException('请求超时，请检查网络后重试');
    } on HandshakeException {
      last = DataException('安全连接失败（HTTPS）');
    } on SocketException {
      last = DataException('网络连接失败，请检查网络');
    } on http.ClientException catch (e) {
      last = DataException('网络请求失败：${e.message}');
    } on HttpException catch (e) {
      last = DataException('网络请求失败：${e.message}');
    } finally {
      client.close();
    }
    if (i < _maxAttempts - 1) {
      await Future<void>.delayed(Duration(milliseconds: 400 * (i + 1)));
    }
  }
  throw last ?? DataException('网络请求失败');
}

/// Minimal GBK decoder for the few characters we need (stock names).
/// Falls back to latin1 for ASCII; Chinese names from some legacy quote endpoints are GBK, which Dart
/// cannot decode natively, so callers that need names should use a different
/// source (we only decode numeric quote fields).
String decodeAscii(Uint8List bytes) => latin1.decode(bytes);

int decimalsOf(String s) {
  final dot = s.indexOf('.');
  if (dot < 0) return 0;
  return s.length - dot - 1;
}
